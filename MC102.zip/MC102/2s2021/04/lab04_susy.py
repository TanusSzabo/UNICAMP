###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 4 - Avatar
# Nome: 
# RA: 
###################################################

# Inicialização das variáveis


# Leitura da sequência de treinamento




# Impressão das informações de saída

print("Pontuacao Final")
print("Agua: {:.1f}".format(water))
print("Terra: {:.1f}".format(earth))
print("Fogo: {:.1f}".format(fire))
print("Ar: {:.1f}".format(air))


print("Treinamento realizado com sucesso.")

print("Realize mais treinamentos.")

