###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 11 - Fuga de Nova York
# Nome: 
# RA: 
###################################################

# Leitura da matriz
# DICA: o método isnumeric() pode ser útil para determinar o fim da leitura da matriz 


# Leitura das coordenadas e início do processamento


# Impressão do resultado para cada coordenada

print("Fuga pelo norte.")

print("Fuga pelo sul.")

print("Fuga pelo leste.")

print("Fuga pelo oeste.")

print("Resgate aereo solicitado.")
