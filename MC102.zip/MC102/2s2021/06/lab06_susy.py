###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 6 - O Porteiro do Castelo
# Nome: 
# RA: 
###################################################

# Leitura de dados

sequencia = [int(i) for i in input().split()]