#####################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 14 - Linha do Tempo Sagrada II
# Nome:
# RA:
#####################################################


"""
Esta função recebe como parâmetro uma matriz, uma posição inicial 
de uma ramificação na matriz determinada pelos parâmetros linha 
e coluna. O retorno esperado para a função é um número inteiro 
indicando a quantidade de eventos nexus gerados pela ramificação.
"""
def eventos_nexus(matriz, linha, coluna):
# ...



# Leitura da matriz

matriz = []
for i in range(11):
    matriz.append(list(input()))

# Deteção dos eventos nexus
  # ...
  print("Ramificacao {0}: {1} Eventos Nexus.".format(coluna, X))
