###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 3 - Cartões de Crédito
# Nome:
# RA:
###################################################

# Leitura de dados



# Verificação se o cartão de crédito será concedido ou não

