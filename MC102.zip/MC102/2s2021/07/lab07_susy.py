###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 7 - Vacinação AstraZeneca
# Nome:
# RA:
###################################################

# Leitura dos dados

N = int(input())

# Listas dos números de vacinados com a primeira e segunda dose em cada mês

D1 = []
D2 = []

# Lista do número de vacinas devolvidas em cada mês

X = []

# Processamento dos dados



# Impressão do uso das vacinas mês a mês

for i in range(N):
    print("Mes " + str(i+1) + ":")
    print("Vacinados com a primeira dose:", D1[i])
    print("Vacinados com a segunda dose:", D2[i])
    print("Vacinas devolvidas:", X[i])

# Impressão do resumo final
    
