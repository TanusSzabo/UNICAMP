###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 1 - Aritmética com Inteiros
# Nome: 
# RA: 
###################################################

a = int(input())
b = int(input())

print(f'{a = }')
print(f'{b = }')
print(f'{a + b = }')
print(f'{a - b = }')
print(f'{a * b = }')
print(f'{a ** b = }')
print(f'{a // b = }')
print(f'{a % b = }')
