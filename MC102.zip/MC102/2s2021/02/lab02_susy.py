###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 2 - Fórmula 1
# Nome: 
# RA: 
###################################################

# Leitura de dados





# Cálculo do tempo total gasto para realizar o pit stop



# Impressão da resposta

