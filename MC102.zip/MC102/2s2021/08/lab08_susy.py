###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 8 - Emparelhamento de Primers
# Nome: 
# RA: 
###################################################

# Leitura de dados


# Verificação da ligação dos primers na fita


# Impressão da saída do programa
