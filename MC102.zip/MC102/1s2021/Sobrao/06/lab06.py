###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 6 - Plataforma
# Nome: Bruno Sobral Ferreira Ruzzi
# RA: 145537
###################################################


# Leitura de dados

plataforma = [int(i) for i in input().split()]
i = int(input())

print(i)

while True:
    pos = i + plataforma[i-1]
    plataforma[i-1] = 0
    if pos > len(plataforma):
        print("direita")
        break
    if pos <= 0:
        print("esquerda")
        break
    if plataforma[pos-1] == 0:
        print("loop")
        break
    i = pos
    print(i)