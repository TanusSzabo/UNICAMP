###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 11 - Jogo da Similaridade Máxima
# Nome:
# RA:
###################################################

"""
Esta função recebe quatro parâmetros: 
 - linha: indíce de uma linha da matriz maior
 - coluna: indice de uma coluna da matriz maior
 - maior: matriz quandrada onde deve ser procurado um padrão 
 - menor: matriz quadrada com um padrão a ser encontrado

A função deve retornar o grau de similaridade entre a submatriz
da matriz maior que começa na posição definida pelos parâmetros 
linha e coluna e a matriz menor
"""

def calcula_similaridade(linha, coluna, maior, menor):
# funções (def) só será lida quando/se chamada no script

    m = len(menor)          # dimensão da matriz menor m x m
    quadrados_totais = m*m  # quantidade de quadrados na matriz
    quadrados_iguais = 0    # variavel para armazenar as igualdades

    for i in range(0, m):     # Para toda linha i
        for j in range(0, m): #e coluna j da matriz menor:
            if menor[i][j] == maior[i+linha][j+coluna]:  # Testa se o item do quadrado menor sobreposto no maior são iguais
                quadrados_iguais += 1                    # adiciona 1 no contador de quadrados iguais

    similaridade = 100 * (quadrados_iguais / quadrados_totais)  # porcentagem na forma 100,00%

    return similaridade    # retorna o valor de similaridade
# fim da função calcula_similaridade


# Leitura das matrizes

n = int(input())  # Tamanho da matriz maior
maior = []        # Variável que armazenará a matriz maior
for i in range(0, n):
    maior.append( [int(j) for j in input().split()] )  # é adicionado uma lista com os valores
                                                       #inteiros do input() separados com .split()

m = int(input())  # Tamanho da matriz menor
menor = []        # Variável que armazenará a matriz menor
for i in range(m):
    menor.append( [int(j) for j in input().split()] )  # é adicionado uma lista com os valores
                                                       #inteiros do input() separados com .split()


# Cálculo da submatriz de similaridade máxima

pos = [0, 0]            # Variável que guarará a posição com maior similaridade
similaridade_maxima = 0 # variável que vai guardar a maior similaridade dentra as possiveis posições

for i in range(0, n):                # Para toda linha i
    for j in range(0, n):            #e coluna j da matriz maior:
        if i + m > n or j + m > n:   # É testado se a matriz menor na posição (i,j) irá ultrapassar a matriz maior
            continue                 #se sim, apenas passa pra próxima interação
        else:                        #se não, podemos calcular a similaridade
            # chamamos a função definida no começo com a matriz menor na posição (i,j)
            similaridade_ij = calcula_similaridade(i, j, maior, menor)
            if similaridade_ij > similaridade_maxima:    # Se a similaridade encontrada for maior que a antes armazenada
                similaridade_maxima = similaridade_ij    #essa é dada como a nova similaridade maxima
                pos = [i, j]                             #e sua posição é guardada


# similaridade
print("Posição: ({0},{1})".format(pos[0], pos[1]))   # imprimimos a posição guardada da similaridade máxima
print("Similaridade máxima: {:.2f}%".format(similaridade_maxima))  # imprimimos a similaridade máxima
