#####################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 9 - Magic: Trocando Cartas
# Nome:
# RA:
###################################################

# Leitura de dados:
#       Leitura das cartas para troca

cartas_para_troca = {}   # dicionário que recebera as cartas como (carta, quantidade)
n = int(input())         # quantidade de cartas para ler
for i in range(n):
    # Separamos a entrada, a primeira parte é o nome da carta e a segunda a quantidade
    carta, quantidade = input().split()         # carta recebe a primeira parte, quantidade recebe a segunda
    cartas_para_troca[carta] = int(quantidade)  # Adicionamos o item carta com a quantidade respectiva


#       Leitura das cartas desejadas

cartas_desejadas = {}    # dicionário que recebera as cartas como (carta, quantidade)
m = int(input())         # quantidade de cartas para ler
for i in range(m):
    # Separamos a entrada, a primeira parte é o nome da carta e a segunda a quantidade
    carta, quantidade = input().split()        # carta recebe a primeira parte, quantidade recebe a segunda
    cartas_desejadas[carta] = int(quantidade)  # Adicionamos o item carta com a quantidade respectiva



# Processamento das trocas

while True:
    entrada = input()
    if entrada == '---':    # Se a entrada for '---' é sinal que o prorama deve parar
        break               # quebramos o while
    # Separamos a entrada, a primeira parte é a carta que a receber e a segunda a carta que precisamos dar
    carta_amigo, carta_joao = entrada.split()

    # Se possuir a carta no baralho do joão, podemos procurar a quantidade delas                               # __
    if carta_joao in cartas_para_troca:                                                                        #   |
        # Se a quantidade de cartas for > 0, podemos ver se não está nas cartas desejados a adiquirir # __     #   |
        if cartas_para_troca[carta_joao] > 0:                                                         #   |    #   |
            # Se existir a carta no dicionário de cartas desejadas, podemos                 # __      #   |    #   |
            #ver se o joão tem cartas sobrando a mais que ele desejava                      #   |     #   |    #   |
            if carta_joao in cartas_desejadas:                                              #   |     #   |    #   |
                # Se ele tiver mais cartas do que queria, a troca é feita        # __       #   |     #   |    #   |
                if cartas_para_troca[carta_joao] > cartas_desejadas[carta_joao]: #   |      #   |     #   |    #   |
                    print("TROCA REALIZADA!")                                    #   |      #   |     #   |    #   |
                    # subtrai 1 da carta que joão deu                            #   |      #   |     #   |    #   |
                    cartas_para_troca[carta_joao] -= 1                           #   |      #   |     #   |    #   |
                    # adiciona 1 no valor da carta adiquirida no baralho         #   |      #   |     #   |    #   |
                    if carta_amigo in cartas_para_troca:                         #   |      #   |     #   |    #   |
                        cartas_para_troca[carta_amigo] += 1                      #   |      #   |     #   |    #   |
                    # se ela não tinha antes no baralho, adiciona ela            #   |      #   |     #   |    #   |
                    else:                                                        #   |      #   |     #   |    #   |
                        cartas_para_troca[carta_amigo] = 1                       #   |      #   |     #   |    #   |
                                                                                 # ==|      #   |     #   |    #   |     
                # Caso joão não tenha a mais dessa carta desejada,               #   |      #   |     #   |    #   |
                # a troca não é feita                                            #   |      #   |     #   |    #   |
                else:                                                            #   |      #   |     #   |    #   |
                    print("TROCA NAO REALIZADA!")                                # __|      #   |     #   |    #   |
                                                                                            # ==|     #   |    #   |
            # Caso a carta dar em troca não seja uma carta carta desejada, a troca é feita  #   |     #   |    #   |
            else:                                                                           #   |     #   |    #   |
                print("TROCA REALIZADA!")                                                   #   |     #   |    #   |
                cartas_para_troca[carta_joao] -= 1                                          #   |     #   |    #   |
                if carta_amigo in cartas_para_troca:                                        #   |     #   |    #   |
                    cartas_para_troca[carta_amigo] += 1                                     #   |     #   |    #   |
                else:                                                                       #   |     #   |    #   |
                    cartas_para_troca[carta_amigo] = 1                                      # __|     #   |    #   |
                                                                                                      # ==|    #   |
        # Caso ele não tenha cartas sobrando da que o amigo quer, a troca não é feita                 #   |    #   |
        else:                                                                                         #   |    #   |
            print("TROCA NAO REALIZADA!")                                                             # __|    #   |
                                                                                                               # ==|
    # Caso a carta que o amigo quer nem consta no baralho do joão, a troca não é feita                         #   |
    else:                                                                                                      #   |
        print("TROCA NAO REALIZADA!")                                                                          # __|


# Processamento se as cartas desejadas foram obtidas

conseguiu = True   # Variável que contabilizara se joão conseguiu ou não as cartas desejadas
for carta in cartas_desejadas:   # Para todas as cartas no dicionário de cartas desejadas

    # Se a carta está no baralho atualizado do joão, podemos ver se ele atinjiu o esperado
    if carta in cartas_para_troca:   
        # Se a quantidade dessa carta for menor do que ele queria, ele não conseguiu  
        if cartas_para_troca[carta] < cartas_desejadas[carta]:
            conseguiu = False
    
    # Se a carta nem consta no baralho atual do joão, ele não conseguiu
    else:
        conseguiu = False
    
    # Caso em qualquer momento seja constado que ele não conseguiu, nem precisa verificar as outras,
    #quebramos o for e vamos pra a impressão
    if conseguiu == False:
        break

# Se algum dos casos acima aconteceu, ele não conseguiu pelo menos uma da quantidade de cartas desejadas
if conseguiu == False:
    print("JOAO NAO CONSEGUIU AS CARTAS DESEJADAS!")

# caso contrário, joão tinha todas as cartas desejadas em quantidades iguais ou maiores às esperadas 
else:
    print("JOAO CONSEGUIU AS CARTAS DESEJADAS!")
