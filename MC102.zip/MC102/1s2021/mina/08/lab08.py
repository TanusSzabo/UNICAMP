###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 8 - O Desafio da Palavra Escondida
# Nome: 
# RA: 
###################################################

# Leitura de dados

n = int( input() )  # número de linhas que o texto terá
texto = []          # lista que receberá as palavras do texto
for i in range( n ):                                # Para cada linha do texto:
    linha_do_texto = input()                        # Lemos a linha do texto
    linha_do_texto = linha_do_texto.lower()         # Atualiza as letras para caixa baixa
    linha_do_texto = linha_do_texto.replace('.','') # Substitui os '.' por nada
    linha_do_texto = linha_do_texto.replace(',','') # Substitui os ',' por nada
    linha_do_texto = linha_do_texto.replace(':','') # Substitui os ':' por nada
    linha_do_texto = linha_do_texto.replace(';','') # Substitui os ';' por nada
    linha_do_texto = linha_do_texto.replace('!','') # Substitui os '!' por nada
    linha_do_texto = linha_do_texto.replace('?','') # Substitui os '?' por nada
    linha_do_texto = linha_do_texto.split()         # Separa a linha em uma lista de palavras
    for j in range(len(linha_do_texto)):            # Usa-se o for para que cada palavra da linha
        texto.append( linha_do_texto[j] )           #seja adicionada individualmente na lista texto

palavra_chave = input()  # Palavra que queremos encontrar no texto



# Verificação da palavra no texto

posicao_palavras = []  # Lista que armazenara a posição das palavras que encontrarmos letras da palavra_chave
posicao_letras = []    # Lista que armazenara a posição das letras nas palavras acima citadas
cont = 0               # Contador para saber qual letra estamos procurando 

for i in range( len(texto) ):                    # Para toda palavra do texto
    letra = texto[i].find( palavra_chave[cont] ) # Procuramos a posição da letra na palavra do texto
    if letra != -1:                              # Se a posição dela for -1, ela não está na palavra
        cont += 1                                # Aumentamos o contador com +1
        posicao_palavras.append(i + 1)           # Adicionamos na lista de palavras a posição da palavra no texto
        posicao_letras.append(letra + 1)         # Adicionamos na lista de letras a posição da letra na palavra
    if cont == len( palavra_chave ):             # Se o contador atingiu o tamanho da palavra procurada,
        break                                    #achamos todas as letras e quebramos a procura do for



# Impressão da saída do programa

if cont == len( palavra_chave ):   # Se o contador atingiu o tamanho da palavra procurada,
    print("Palavra encontrada")    #achamos todas as letras e imprimimos elas e suas posições em ordem
    for i in range( len(palavra_chave) ):
        print( "{0}: palavra {1}, letra {2}".format(palavra_chave[i], posicao_palavras[i], posicao_letras[i]) )

else:                              # Se não, só imprimimos 'Palavra nao encontrada'
    print("Palavra nao encontrada")
