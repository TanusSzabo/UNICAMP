l=int(input())

for texto in range (l):
    texto = str(texto) + input().lower()

buscar = (input().lower())

#indice para guardar as letras e palavras 
indice_letras = str (0)
indice_palavras = str (0)

#variavel para contar quantas letras encontramos
i_p = 0
j_l = 0


while i_p < len(indice_palavras):
    print(indice_palavras[i_p])
    i_p = i_p + 1

while j_l < len(indice_palavras):
    print(indice_palavras[j_l])
    j_l = j_l + 1

print(texto)
for i_p in buscar:
    texto_lista = texto.split()
    for i_t in range( len(texto_lista) ):
        palavra = texto_lista[i_t].find(i_p)
        if palavra != -1:
            letra = i_p
            indice_palavras = i_t + 1
            indice_letras = palavra + 1
            print (letra, indice_palavras, indice_letras)
            break
        else:
            if j_l == buscar:
                print ("Palavra não encontrada")
