###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 13 - Super Trunfo
# Nome: 
# RA: 
###################################################

def insertion_sort(matriz, item):     # função de ordenamento de matriz pelo método de inserção
    insercoes = 0                     # contador de inserções realizadas

    for i in range(1, len(matriz)):   # para todos os itens a partir do segundo
        valor = matriz[i]             # guarda o valor referente ao item
        j = i-1                       # a partir do item anterior
        while j >= 0 and valor[item] > matriz[j][item]:  # se o valor a interir for maior que o valor anterior
            matriz[j+1] = matriz[j]   # vai passando os valores pra direita
            j -= 1                    # diminui o contador do item

        matriz[j+1] = valor  # insere o valor na casa encontrada na posição top!
        if j < i-1:          # se o j foi alterado/diminuido o valor
            insercoes +=1    # a carta foi inserida no meio de outras

    return insercoes  # retorna os valores de inserções no ordenamento
            


# Leitura das cartas

qtde_cartas = int( input() )  # quantidade de cartas que terão
campos = input().split()      # os títulos dos atributos
cartas = []                   # variável que guardará o valor das cartas

for i in range(qtde_cartas):                # para todas as cartas
    entrada = input().split()               # pega a entrada splitada
    cartas.append( [entrada[0]] )           # Adiciona o nome da carta
    for j in range(1, len(entrada)):        # para os outros valores da carta
        cartas[i].append( int(entrada[j]) ) # adiciona os valores transformados em inteiros

ordens = input().split()  # ordem de preferência para ordenamento


# Ordenação das cartas

contador_de_insercoes = 0  # contador de inserções feitas ao todo

for i in range( len(ordens) ):  # para todos os itens a serem ordenados
    item = campos.index( ordens[len(ordens)-i-1] )  # pega o item preferido a ordenar, começando pelo de menor prioridade
    contador_de_insercoes += insertion_sort(cartas, item)  # ordena as cartas, adicionando o número de inserções no contador


# Impressão dos dados

print('{:15s}'.format(campos[0]), ''.join('{:>10}'.format(campo) for campo in campos[1:]))

for carta in cartas:
    print('{:15s}'.format(carta[0]), ''.join('{:>10}'.format(atributo) for atributo in carta[1:]))
print('Insercoes realizadas:', contador_de_insercoes)