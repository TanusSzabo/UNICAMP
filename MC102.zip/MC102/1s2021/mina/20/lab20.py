###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 20 - De salto em salto
# Nome: 
# RA: 
###################################################


'''
Dada uma matriz e a posição (x,y) de uma possível pessoa infectada,
atualiza a matriz para que cada caractere correspondente a uma pessoa
infectada seja substituído por 'X'.
'''
def propagação_de_fake_news(matriz, x, y):
    pessoa = matriz[x][y]      # pega qual a pessoa na posição
    if pessoa.isdigit():       # se a pessoa for um espalhador de fake
        alcance = int(pessoa)  # pega o alcance dessa pessoa
        matriz[x][y] = 'X'     # substitui o valor dela por X

        # Leste
        for posicao in range(x+1, x+(alcance+1), +1):  # x+1, x+2, ..., x+(alcance-1), x+(alcance)
            if posicao < 0 or posicao >= len(matriz):        # se a posiçao saiu do mapa, quebra o for
                break
            elif matriz[posicao][y] == '#':                  # se na posiçao tiver uma barreira, quebra o for
                break
            elif matriz[posicao][y] == '.':                  # se na posição tiver nada, só continua
                continue
            elif matriz[posicao][y].isdigit():               # se na posição tiver um propagador de fake
                propagação_de_fake_news(matriz, posicao, y)  # chama a função de espalhar pra ele

        # Norte
        for posicao in range(y+1, y+(alcance+1), +1): # y+1, y+2, ..., y+(alcance-1), y+(alcance)
            if posicao < 0 or posicao >= len(matriz[x]):
                break
            elif matriz[x][posicao] == '#':
                break
            elif matriz[x][posicao] == '.':
                continue
            elif matriz[x][posicao].isdigit():
                propagação_de_fake_news(matriz, x, posicao)

        # Oeste
        for posicao in range(x-1, x-(alcance+1), -1): # x-1, x-2, ..., x-(alcance-1), x-(alcance)
            if posicao < 0 or posicao >= len(matriz):
                break
            elif matriz[posicao][y] == '#':
                break
            elif matriz[posicao][y] == '.':
                continue
            elif matriz[posicao][y].isdigit():
                propagação_de_fake_news(matriz, posicao, y)

        # Sul
        for posicao in range(y-1, y-(alcance+1), -1): # y-1, y-2, ..., y-(alcance-1), y-(alcance)
            if posicao < 0 or posicao >= len(matriz[x]):
                break
            elif matriz[x][posicao] == '#':
                break
            elif matriz[x][posicao] == '.':
                continue
            elif matriz[x][posicao].isdigit():
                propagação_de_fake_news(matriz, x, posicao)
  


# Leitura de dados
n = int(input())
matriz = []
for _ in range(n):
    matriz.append(list(input()))
x, y = [int(i) for i in input().split()]

# Atualiza a matriz com a propagação da noticia falsa.
propagação_de_fake_news(matriz, x, y)

# Impressão do resultado
for line in matriz:
    print("".join(line))
