###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 12 - Processamento de Imagens
# Nome: 
# RA: 
###################################################

def imprimir_imagem(imagem):   # Função para imprimir a matriz da imagem bonitinha
    print("P2")   # Imprime o tipo da imagem 'P2'
    print(len(imagem[0]), len(imagem))  # Imprime o tamanho da imagem (linhas, colunas)
    print("255")   # imprime o valor máximo do pixel
    for i in range(len(imagem)):   # para toda linha da imagem
        print(" ".join(str(x) for x in imagem[i]))  # imprime a linha juntinha bonitinho


def flip_horizontal(imagem_original):  # Função filtro que espelha a imagem horizontalmente
    imagem = []    # variável que armazenará a imagem após o filtro
    n = len(imagem_original)     # quantidade de linhas da imagem original
    m = len(imagem_original[0])  # quantidade de colunas da imagem original

    for i in range(n):           # para toda linha da imagem original
        imagem.append([])        # adiciona uma lista nula que armazenará a linha da imagem com filtro
        for j in range(m):       # para toda coluna da imagem original
            imagem[i].append( imagem_original[i][m-j-1] )  # adiciona o valor da coluna oposta à que está

    return imagem  # retorna a imagem com filtro


def flip_vertical(imagem_original):  # Função filtro que espelha a imagem verticalmente
    imagem = []    # variável que armazenará a imagem após o filtro
    n = len(imagem_original)     # quantidade de linhas da imagem original
    m = len(imagem_original[0])  # quantidade de colunas da imagem original

    for i in range(n):           # para toda linha da imagem original
        imagem.append([])        # adiciona uma lista nula que armazenará a linha da imagem com filtro
        for j in range(m):       # para toda coluna da imagem original
            imagem[i].append( imagem_original[n-i-1][j] )  # adiciona o valor da linha oposta à que está

    return imagem  # retorna a imagem com filtro
    

def shift_vertical(imagem_original, x):  # Função filtro que defasa a imagem verticalmente
    imagem = []    # variável que armazenará a imagem após o filtro
    n = len(imagem_original)     # quantidade de linhas da imagem original
    m = len(imagem_original[0])  # quantidade de colunas da imagem original

    for i in range(n):           # para toda linha da imagem original
        imagem.append([])        # adiciona uma lista nula que armazenará a linha da imagem com filtro
        for j in range(m):       # para toda coluna da imagem original
            imagem[i].append( imagem_original[i-x][j] )  # adiciona o valor da linha defasada x casas à que está

    return imagem  # retorna a imagem com filtro
    

def shift_horizontal(imagem_original, x):  # Função filtro que defasa a imagem verticalmente
    imagem = []    # variável que armazenará a imagem após o filtro
    n = len(imagem_original)     # quantidade de linhas da imagem original
    m = len(imagem_original[0])  # quantidade de colunas da imagem original

    for i in range(n):           # para toda linha da imagem original
        imagem.append([])        # adiciona uma lista nula que armazenará a linha da imagem com filtro
        for j in range(m):       # para toda coluna da imagem original
            imagem[i].append( imagem_original[i][j-x] )  # adiciona o valor da coluna defasada x casas à que está

    return imagem  # retorna a imagem com filtro
    

def crop(imagem_original, x1, y1, x2, y2):  # Função filtro que corta a imagem da posição (x1, y1) a (x2, y2)
    imagem = []    # variável que armazenará a imagem após o filtro
    n = len(imagem_original)     # quantidade de linhas da imagem original
    m = len(imagem_original[0])  # quantidade de colunas da imagem original
    linha = 0      # variável que contará em qual linha da imagem cortada que estamos

    for i in range(x1-1, x2):      # para toda linha dentro do corte que queremos fazer
        imagem.append([])          # adiciona uma lista nula que armazenará a linha da imagem com filtro
        for j in range(y1-1, y2):  # para toda coluna dentro do corte que queremos fazer
            imagem[linha].append( imagem_original[i][j] )  # adiciona o valor da imagem original na cortada
        linha +=1   # aumenta 1 no valor da linha da imagem cortada que estamos

    return imagem  # retorna a imagem com filtro
    

def shrink(imagem_original):  # Função filtro que 'encolhe 2x' a imagem
    imagem = []    # variável que armazenará a imagem após o filtro
    n = len(imagem_original)     # quantidade de linhas da imagem original
    m = len(imagem_original[0])  # quantidade de colunas da imagem original

    # montando a imagem com filtro com metade do tamanho da original
    for i in range( int(n/2) ):      # para metade das linhas da imagem original
        imagem.append([])            # adiciona uma lista nula que armazenará a linha da imagem com filtro
        for j in range( int(m/2) ):  # para metade das colunas da imagem original
            imagem[i].append( 0 )    # adiciona um 0 para montar uma imagem com apenas zeros

    for i in range(n):           # para toda linha da imagem original
        for j in range(m):       # para toda coluna da imagem original
            # testa se o pixel da imagem original é maior que aquele respectivo pixel encolhido da imagem com filtro
            if imagem_original[i][j] > imagem[int(i/2)][int(j/2)]:
                imagem[int(i/2)][int(j/2)] = imagem_original[i][j] # se for, substitui o valor do pixel encolhido

    return imagem  # retorna a imagem com filtro
    


# leitura da imagem

_ = input() #P2 - linha a ser ignorada

m, n = [int(x) for x in input().split()]  # tamanho da imagem (coluna, linha)

_ = input() #255 - linha a ser ignorada

imagem_original = []   # variável que armazenará a imagem original
for i in range(n):     # para toda linha da imagem
    linha = [int(x) for x in input().split()]  # adiciona os valores separadinhos numa lista linha
    imagem_original.append(linha)   # adiciona a lista linha na matriz



# leitura da operação e parâmetros

filtro = input()   # filtro dado pelo usuário

if filtro == 'flip':   # se o filtro for de espelhar a imagem
    filtro2 = input()  # precisamos saber se o espelhamento será horizontal ou vertical
    if filtro2 == 'horizontal':  # se for horizontal
        imagem = flip_horizontal(imagem_original)  # chama a função flip_horizontal
    else:   # senão, será o vertical
        imagem = flip_vertical(imagem_original)    # então chama a função flip_vertical

elif filtro == 'shift':   # se o filtro for de shiftar a imagem
    filtro2 = input()     # precisamos saber se o shift será horizontal ou vertical
    x = int(input())      # e de quantas casas será o shift
    if filtro2 == 'horizontal':  # se o shift for horizontal
        imagem = shift_horizontal(imagem_original, x)  # chama a função shift_horizontal
    else:   # senão, será o vertical
        imagem = shift_vertical(imagem_original, x)    # então chama a função shift_vertical

elif filtro == 'crop':       # se o filtro for de cortar a imagem
    x1, y1 = input().split() # precisamos saber a posição do começo do corte
    x2, y2 = input().split() # e do final do corte
    imagem = crop(imagem_original, int(x1), int(y1), int(x2), int(y2)) # chamamos a função crop com as posições do corte

else:   # se não for nenhum dos outros filtros, então é o shrink
    imagem = shrink(imagem_original)  # chamamos a função shrink



# impressão da imagem final

imprimir_imagem(imagem)   # chama a função de impressão da imagem