###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 10 - Caça ao Tesouro
# Nome: 
# RA: 
###################################################


# Leitura da matriz

campo = []              # lista que vai armazenar as listas de linhas do campo
tamanho_do_campo = 8    # tamanho do campo (fixo em 8x8)
for i in range(tamanho_do_campo):
    campo.append(input().split())   # adiciona a lista dada pela entrada splitada


# Leitura e processamento dos sensores

num_sensores = int(input())   # número de sensores que serão colocados
alcance = int(input())        # alcance dos sensores

tesouros = 0                  # contador de tesouros encontrados
for i in range(num_sensores): # para todos os sensores:
    linha, coluna = [int(i) for i in input().split()]  # le-se a posição do sensor
    """ Comentário com exemplos
    Sensor livre pra procurar:    Sendo parado por uma barreira ou pelo limite do campo: 
    (4, 3), alcance 2             (3, 6), alcance 3, barreira (1,6)            
      0 1 2 3 4 5 6 7                  0 1 2 3 4 5 6 7
    0 . . . . . . . .                0 . . . . . . . .
    1 . . . . . . . .                1 . . . . . . o . (parado pela barreira 'o')
    2 . . . X . . . .                2 . . . . . . X .
    3 . . . X . . . .                3 . . . X X X X X (parado pelo limite do campo)
    4 . X X X X X . .                4 . . . . . . X .
    5 . . . X . . . .                5 . . . . . . X .
    6 . . . X . . . .                6 . . . . . . X .
    7 . . . . . . . .                7 . . . . . . . .
    """

    # Posicao do sensor:
    if campo[linha][coluna] == 'x':    # se na posiçao tiver um tesouro
        campo[linha][coluna] = '.'     # "pega o tesouro"/substitui o valor pelo referente à nada
        tesouros += 1                  # aumenta um tesouro na conta

    # a partir daqui, serão repetidos os processos de procura para as 4 coordenadas (Leste, Norte, Oeste e Sul)

    # Leste
    for posicao in range(linha+1, linha+(alcance+1), +1):  # linha+1, linha+2, ..., linha+(alcance-1), linha+(alcance)
        if posicao < 0 or posicao >= tamanho_do_campo:     # se a posiçao saiu do mapa, quebra o for
            break
        elif campo[posicao][coluna] == 'o':                # se na posiçao tiver uma barreira, quebra o for
            break
        elif campo[posicao][coluna] == '.':                # se na posição tiver nada, só continua
            continue
        elif campo[posicao][coluna] == 'x':                # se na posição tiver um tesouro:
            campo[posicao][coluna] = '.'                   # "pega o tesouro"/substitui o valor pelo referente à nada
            tesouros += 1                                  # aumenta um tesouro na conta

    # Norte
    for posicao in range(coluna+1, coluna+(alcance+1), +1): # coluna+1, coluna+2, ..., coluna+(alcance-1), coluna+(alcance)
        if posicao < 0 or posicao >= tamanho_do_campo:
            break
        elif campo[linha][posicao] == 'o':
            break
        elif campo[linha][posicao] == '.':
            continue
        elif campo[linha][posicao] == 'x':
            campo[linha][posicao] = '.'
            tesouros += 1

    # Oeste
    for posicao in range(linha-1, linha-(alcance+1), -1): # linha-1, linha-2, ..., linha-(alcance-1), linha-(alcance)
        if posicao < 0 or posicao >= tamanho_do_campo:
            break
        elif campo[posicao][coluna] == 'o':
            break
        elif campo[posicao][coluna] == '.':
            continue
        elif campo[posicao][coluna] == 'x':
            campo[posicao][coluna] = '.'
            tesouros += 1

    # Sul
    for posicao in range(coluna-1, coluna-(alcance+1), -1): # coluna-1, coluna-2, ..., coluna-(alcance-1), coluna-(alcance)
        if posicao < 0 or posicao >= tamanho_do_campo:
            break
        elif campo[linha][posicao] == 'o':
            break
        elif campo[linha][posicao] == '.':
            continue
        elif campo[linha][posicao] == 'x':
            campo[linha][posicao] = '.'
            tesouros += 1
  


# Impressão da saída

if tesouros > 0:   # Se encontrou baús, printa quantos baus encontrou
    print("{} bau(s) encontrado(s).".format(tesouros))

else:              # Senão, printa que não encontrou
    print("Nenhum bau encontrado.")



