###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 12 - Processamento de Imagens
# Nome: Bruno Sobral Ferreira Ruzzi
# RA: 145537
###################################################


def imprimir_imagem(imagem, image_type, max_pixel_value):
    print(image_type)
    print(len(imagem[0]), len(imagem))
    print(max_pixel_value)
    for i in range(len(imagem)):
        print(" ".join(str(x) for x in imagem[i]))


def flip_horizontal(imagem):
    n = len(imagem)
    m = len(imagem[0])
    for i in range(n):
        for j in range( int(m/2) ):
            imagem[i][j], imagem[i][m-j-1] = imagem[i][m-j-1], imagem[i][j]
    
    return imagem
    

def flip_vertical(imagem):
    n = len(imagem)
    for i in range( int(n/2) ):
        imagem[i], imagem[n-i-1] = imagem[n-i-1], imagem[i]
    
    return imagem
    

def shift_vertical(imagem_original, x):
    n = len(imagem_original)
    imagem = []
    for i in range(n):
        imagem.append(imagem_original[ (i-x)%n ])
    
    return imagem

def shift_horizontal(imagem_original, x):
    n = len(imagem_original)
    m = len(imagem_original[0])
    imagem = []
    for i in range(n):
        linha = []
        for j in range(m):
            linha.append( imagem_original[i][ (j-x)%m ] )
        imagem.append(linha)
    
    return imagem
    

def crop(imagem_original, x1, y1, x2, y2):
    n = len(imagem_original)
    m = len(imagem_original[0])
    imagem = []
    for i in range(x1-1, x2):
        linha = []
        for j in range(y1-1, y2):
            linha.append( imagem_original[i][j] )
        imagem.append(linha)
    
    return imagem


def shrink(imagem_original):
    n = len(imagem_original)
    m = len(imagem_original[0])
    imagem = []
    for i in range(0,n,2):
        linha = []
        for j in range(0,m,2):
            grandissicero = 0 
            for i2 in range(i,i+2):
                for j2 in range(j,j+2):
                    if imagem_original[i2][j2] > grandissicero:
                        grandissicero = imagem_original[i2][j2]
            linha.append( grandissicero )
        imagem.append(linha)
    
    return imagem

    

# leitura da imagem
image_type = input() #P2 - linha a ser ignorada

m, n = [int(x) for x in input().split()]

max_pixel_value = input() #255 - linha a ser ignorada
# IGNORADA O CARALHO, VALOR IMPORTANTE, PARA DE SER UM PED/PAD/PROFESSOR BABACA 
# QUE NÃO ENSINA OS ALUNOS ESSAS COISAS LEGAIS DA PROGRAMAÇÃO

imagem_original = []
for i in range(n):
    linha = [int(x) for x in input().split()]
    imagem_original.append(linha)

# leitura da operação e parâmetros
filtro = input()
if filtro == 'flip':
    direcao = input()
    if direcao == 'horizontal':
        imagem = flip_horizontal(imagem_original)
    else:
        imagem = flip_vertical(imagem_original)

elif filtro == 'shift':
    direcao = input()
    x = int(input())
    if direcao == 'horizontal':
        imagem = shift_horizontal(imagem_original, x)
    else:
        imagem = shift_vertical(imagem_original, x)

elif filtro == 'crop':
    x1, y1 = input().split()
    x2, y2 = input().split()
    imagem = crop(imagem_original, int(x1), int(y1), int(x2), int(y2))

else: # filtro == 'shrink':
    imagem = shrink(imagem_original)

# impressão da imagem final
imprimir_imagem(imagem, image_type, max_pixel_value)
