###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 12 - Filtros de Imagens
# Nome: Hey Mount
# RA: é o número de pontolas que vou ganhar
###################################################

from os.path import dirname

def imprime_imagem(imagemfim):
    fsaida = open(dirname(__file__) + "/imagesaida.pgm", "w+")
    fsaida.write(formato + "\n")
    fsaida.write(str(len(imagemfim[0])) + " " + str(len(imagemfim)) + "\n")
    fsaida.write(str(maximo) + "\n")
    for i in range(len(imagemfim)):
        fsaida.write(" ".join(str(x) for x in imagemfim[i]))
        fsaida.write("\n")

def mediana(lista):
    lista_ordenada = sorted(lista)
    elemento_central = len(lista_ordenada) // 2
    if len(lista) % 2 == 1:
        return lista_ordenada[elemento_central]
    else:
        #retorna a parte inteira da média entre os elementos centrais
        return (lista_ordenada[elemento_central-1] + lista_ordenada[elemento_central]) // 2

def filtro_negativo(imagem, maximo):
    for i in range(len(imagem)):
        for j in range(len(imagem[0])):
            imagem[i][j] = maximo - int(imagem[i][j])
    return imagem

def filtro_mediana(imagem):
    imagemnova = []
    for i in range(0,len(imagem)):
        imagemlinha = []
        for j in range(0,len(imagem[0])):
            lista = []
            for p in range(i-1, i+2):
                if p < 0 or p > len(imagem)-1:
                    pass
                else:
                    for q in range(j-1, j+2):
                        if q < 0 or q > len(imagem[0])-1:
                            pass
                        else:
                            lista.append(int(imagem[p][q]))
                                
            imagemlinha.append(mediana(lista)) 
        imagemnova.append(imagemlinha)

    return imagemnova

def convolucao(imagem, M, D, maximo):
    imagemnova = []

    for i in range(1,len(imagem)-1):
        imagemlinha = []
        for j in range(1,len(imagem[0])-1):
            lista = 0
            for p in range(i-1, i+2):
                if p < 0 or p > len(imagem)-1:
                    pass
                else:
                    for q in range(j-1, j+2):
                        if q < 0 or q > len(imagem[0])-1:
                            pass
                        else:
                            lista = lista + int(imagem[p][q])*M[p-i+1][q-j+1]
            if lista < 0:
                lista = 0
            if lista > maximo:
                lista = maximo
            lista = int(lista/D)                    
            imagemlinha.append(lista) 
        imagemnova.append(imagemlinha)

    return imagemnova


f = open(dirname(__file__) + '/baboon.ascii.txt', 'r')
f.seek(0)
lines=f.readlines()

filtro = input()
formato = lines[0]
m, n = [int(x) for x in lines[1].split()]
maximo = int(lines[2])

imagem = []
for i in range(n):
    m_arquivo = 0
    linha_m = []
    while m_arquivo < m:
        linha_m.append(int(x) for x in lines[i+3].split())
        m_arquivo = len(linha_m)
    imagem.append(linha_m)

M = [[0,0,0],[0,1,0],[0,0,0]]
D = 1

if filtro == "negativo":
    imagem = filtro_negativo(imagem, maximo)

elif filtro == "mediana":
    imagem = filtro_mediana(imagem)

elif filtro == "blur":
    M = [[1,1,1],[1,1,1],[1,1,1]]
    D = 9
    imagem = convolucao(imagem, M, D, maximo)
    
elif filtro == "sharpen":
    M = [[0,-1,0],[-1,5,-1],[0,-1,0]]
    D = 1
    imagem = convolucao(imagem, M, D, maximo)

elif filtro == "edge-detect":
    M = [[-1,-1,-1],[-1,8,-1],[-1,-1,-1]]
    D = 1
    imagem = convolucao(imagem, M, D, maximo)
    
imprime_imagem(imagem)
