###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 7 - A Viagem
# Nome: Bruno Sobral Ferreira Ruzzi
# RA: 145537
###################################################

# Leitura de dados

n = int( input() )
capacidade = int( input() )
pesos = []
valores = []

for i in range(0, n):
    pesos.append( int( input() ) )
    if pesos[i]>capacidade:
        NEM_NOE = True

for i in range(0, n):
    valores.append( int( input() ) )


# Escolha dos itens da mochila

razao = []

for i in range(0, n):
    razao.append( valores[i]/pesos[i] )

for i in range(n-1,0,-1):   # arrumando em ordem de pesos
    for j in range(0, i):
        if pesos[j]>pesos[j+1]:
            razao[j], razao[j+1] = razao[j+1], razao[j]
            pesos[j], pesos[j+1] = pesos[j+1], pesos[j]
            valores[j], valores[j+1] = valores[j+1], valores[j]

for i in range(n-1,0,-1):   # arrumando em ordem da razão
    for j in range(0, i):
        if razao[j]>razao[j+1]:
            razao[j], razao[j+1] = razao[j+1], razao[j]
            pesos[j], pesos[j+1] = pesos[j+1], pesos[j]
            valores[j], valores[j+1] = valores[j+1], valores[j]

peso_total = 0
valor_total = 0

for i in range(n-1, -1, -1):   # vendo ao contrário para pegar as maiores razões primeiro
    if capacidade - peso_total >= pesos[i]:
        peso_total = peso_total + pesos[i]
        valor_total = valor_total + valores[i]

# Saída de dados

print(valor_total)
print(peso_total)
