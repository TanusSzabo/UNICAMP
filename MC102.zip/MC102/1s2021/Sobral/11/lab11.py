###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 11 - Jogo da Similaridade Máxima
# Nome: Bruno Sobral Ferreira Ruzzi
# RA: 145537
###################################################

"""
Esta função recebe quatro parâmetros: 
 - linha: indíce de uma linha da matriz maior
 - coluna: indice de uma coluna da matriz maior
 - maior: matriz quandrada onde deve ser procurado um padrão 
 - menor: matriz quadrada com um padrão a ser encontrado

A função deve retornar o grau de similaridade entre a submatriz
da matriz maior que começa na posição definida pelos parâmetros 
linha e coluna e a matriz menor
"""

def calcula_similaridade(linha, coluna, maior, menor):

    chance_dela_me_dar_moral = 0
    quantas_vezes_ela_me_deu_moral = 0
    quantas_vezes_eu_tentei = 0
    n = len(menor)

    for i in range(n):
        for j in range(n):
            if maior[i+linha][j+coluna] == menor[i][j]:
                quantas_vezes_ela_me_deu_moral += 1
            quantas_vezes_eu_tentei += 1
    
    chance_dela_me_dar_moral = quantas_vezes_ela_me_deu_moral / quantas_vezes_eu_tentei
    return chance_dela_me_dar_moral
	

# Leitura das matrizes

n = int( input() )
grandissicero = []
for i in range(n):
    grandissicero.append( [int(x) for x in input().split()] )

m = int( input() )
pequenissimo = []
for i in range(m):
    pequenissimo.append( [int(x) for x in input().split()] )


# Cálculo da submatriz de similaridade máxima

pos = [0, 0]
prob = 0

for i in range(0, n-m+1):
    for j in range(0, n-m+1):
        agora_vai = calcula_similaridade(i, j, grandissicero, pequenissimo)
        if agora_vai > prob:
            prob = agora_vai
            pos = [i, j]
        if prob == 1:
            break
    if prob == 1:
        break


# similaridade
print("Posição: ({0},{1})".format(pos[0], pos[1]))
print("Similaridade máxima: {:.2f}%".format(prob*100))
