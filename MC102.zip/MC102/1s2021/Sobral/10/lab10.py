###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 10 - Caça ao Tesouro
# Nome: Bruno Sobral Ferreira Ruzzi
# RA: 145537
###################################################
# Enunciado:

# Você encontrou um mapa do tesouro. Depois de seguir todas as pistas e instruções desse mapa,
# você chegou na região final demarcada no mapa. Contudo, esse mapa não marca as coordenadas
# precisas de onde os baús de tesouro estão enterrados, e você terá que explorar essa região
# em busca desses baús. Para agilizar essa exploração, você comprou um drone que é capaz de
# espalhar sensores sobre o campo. Esses sensores conseguem explorar a região onde pousam,
# além de regiões nas quatro direções (norte, sul, leste, oeste), e identificar se existe
# um baú enterrado naquela região.

# Antes de espalhar os sensores, você decide executar algumas simulações em seu computador.
# Nessa simulação, você espalha todos os sensores sobre o campo e verifica se algum deles
# encontra o tesouro. Nessa primeira fase, você também decide dividir o campo em 64 regiões
# dispostas em um formato de matriz 8 x 8. Cada simulação deve estar preparada para testar
# sensores com diferentes alcances. O alcance de um sensor é medido em número de regiões que
# ele consegue escanear nas direções norte, sul, leste e oeste.

# Um detalhe importante sobre os sensores, é que eles não funcionam em certas regiões, chamadas
# de zonas mortas. Se o sensor encontra uma zona morta em uma das direções, essa zona vira uma
# barreira e o sensor não consegue escanear regiões além da zona morta.

# Você decide começar com um programa simples, que recebe como entrada uma possível configuração do
# campo a ser explorado (isto é, uma matriz 8 x 8), um número n de sensores, o alcance desses sensores,
# e uma sequência de n coordenadas (linha e coluna) indicando a região do campo onde os sensores pousarão.

# Na entrada do seu programa, cada região do campo estará marcada com uma das três opções a seguir:
#  . indica uma região que pode ser escaneada pelo sensor, mas que não contém um baú de tesouro;
#  x indica uma região que pode ser escaneada pelo sensor e contém um baú de tesouro;
#  o indica uma zona morta, isto é, ao encontrar essa região o sensor não pode continuar escaneando nessa direção.



# Leitura da matriz

campo = []
for i in range(8):
  campo.append(input().split())

# Leitura e processamento dos sensores

num_sensores = int(input())
alcance = int(input())
shakeit_bololo = 0

for i in range(num_sensores):
    linha, coluna = [int(i) for i in input().split()]
    # Norte
    for i in range(alcance+1):
        if 0 <= coluna+i <= 7:
            if campo[linha][coluna+i] == 'o':
                break
            elif campo[linha][coluna+i] == 'x':
                shakeit_bololo += 1
                campo[linha][coluna+i] = '.'
    # Sul
    for i in range(alcance+1):
        if 0 <= coluna-i <= 7:
            if campo[linha][coluna-i] == 'o':
                break
            elif campo[linha][coluna-i] == 'x':
                shakeit_bololo += 1
                campo[linha][coluna-i] = '.'
    # Leste
    for i in range(alcance+1):
        if 0 <= linha+i <= 7:
            if campo[linha+i][coluna] == 'o':
                break
            elif campo[linha+i][coluna] == 'x':
                shakeit_bololo += 1
                campo[linha+i][coluna] = '.'
    # Oeste
    for i in range(alcance+1):
        if 0 <= linha-i <= 7:
            if campo[linha-i][coluna] == 'o':
                break
            elif campo[linha-i][coluna] == 'x':
                shakeit_bololo += 1
                campo[linha-i][coluna] = '.'
  

# Impressão da saída

if shakeit_bololo > 0:
    print("{} bau(s) encontrado(s).".format(shakeit_bololo))
else:
    print("Nenhum bau encontrado.")



