###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 3 - Imposto de Renda
# Nome: 
# RA: 
###################################################

# Leitura de dados

rend_trib = float(input())
gasto_prev = float(input())
gasto_edu = float(input())
imp_ret = float(input())

# Abatimento com calculo simplificado

base_simplificado = rend_trib * 0.8  # simplificado = 80% renda

# Abatimento com calculo completo

if gasto_prev > rend_trib * 0.12:
    gasto_prev = rend_trib * 0.12  # o retirado com gasto com a previdência deve ser no máximo 12% da renda

if gasto_edu > 3561.50:
    gasto_edu = 3561.50  # o retirado com gasto com educação deve ser no máximo R$ 3561.50

base_completo = rend_trib - gasto_edu - gasto_prev # completo = renda - gasto_educação - gasto_previdência

# Calculo do IR com calculo simplificado

if base_simplificado < 22847.77:                           # 00000.00 - 22847.76
    ir_simplificado = 0.00

elif base_simplificado < 33919.81:                         # 22847.77 - 33919.80
    ir_simplificado = 0.075 * base_simplificado - 1713.58

elif base_simplificado < 45012.61:                         # 33919.81 - 45012.60
    ir_simplificado = 0.15 * base_simplificado - 4257.57

elif base_simplificado < 55976.16:                         # 45012.61 - 55976.15
    ir_simplificado = 0.225 * base_simplificado - 7633.51

else:                                                      # > 55976.16
    ir_simplificado = 0.275 * base_simplificado - 10432.32

# Calculo do IR com calculo completo

if base_completo < 22847.77:                           # 00000.00 - 22847.76
    ir_completo = 0.00
elif base_completo < 33919.81:                         # 22847.77 - 33919.80
    ir_completo = 0.075 * base_completo - 1713.58
elif base_completo < 45012.61:                         # 33919.81 - 45012.60
    ir_completo = 0.15 * base_completo - 4257.57
elif base_completo < 55976.16:                         # 45012.61 - 55976.15
    ir_completo = 0.225 * base_completo - 7633.51
else:                                                  # > 55976.16
    ir_completo = 0.275 * base_completo - 10432.32


# Calculo do IR devido com calculo simplificado

ajuste_simplificado = ir_simplificado - imp_ret

# Calculo do IR devido com calculo completo

ajuste_completo = ir_completo - imp_ret


# Saída
print("Base de calculo (Simplificado):", format(base_simplificado, ".2f").replace(".", ","))
print("Base de calculo (Completo):", format(base_completo, ".2f").replace(".", ","))
print("Valor do IR (Simplificado):", format(ir_simplificado, ".2f").replace(".", ","))
print("Valor do IR (Completo):", format(ir_completo, ".2f").replace(".", ","))
print("Valor do ajuste (Simplificado):", format(ajuste_simplificado, ".2f").replace(".", ","))
print("Valor do ajuste (Completo):", format(ajuste_completo, ".2f").replace(".", ","))