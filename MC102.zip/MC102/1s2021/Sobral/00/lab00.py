###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 00 - Contagem de linhas e caracteres
# Nome: Bruno Sobral Ferreira Ruzzi
# RA: 145537
###################################################

num = int(input())
dados = []
letters = 0
for i in range(num):
    dados.append(input())
    letters = letters + len(dados[i])

print('Caracteres:', str(letters))
print('Linhas:    ', str(len(dados)))