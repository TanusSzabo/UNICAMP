###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 5 - Super Sete
# Nome: Bruno Sobral Ferreira Ruzzi
# RA: 145537
###################################################

# Leitura de dados

n1 = int(input())
n3 = int(input())
n4 = int(input())
n6 = int(input())

# Impressão dos quatro números das colunas fornecidos como entrada

print("Primeira:", n1)
print("Terceira:", n3)
print("Quarta:", n4)
print("Sexta:", n6)

# Processamento e impressão da lista de possíveis apostas

print("Lista de apostas:")

for n2 in range(n1, n3+1):
    for n5 in range(n4, n6+1):
        for n7 in range(n6, 10):
            soma = n1 + n2 + n3 + n4 + n5 + n6 + n7
            if soma%7 == 0 or soma%13 == 0:
                joao_eh_um_noia = True
            else:
                print("{} - {} - {} - {} - {} - {} - {}".format(n1, n2, n3, n4, n5, n6, n7))
