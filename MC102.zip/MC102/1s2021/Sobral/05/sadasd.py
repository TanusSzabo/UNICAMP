n1 = int(input())
n3 = int(input())
n4 = int(input())
n6 = int(input())

print("Primeira:", n1)
print("Terceira:", n3)
print("Quarta:", n4)
print("Sexta:", n6)

n2 = 0
n5 = 0 
n7 = 0

x = {n1} - {n2} - {n3} - {n4} - {n5} - {n6} - {n7}
print(x)
# x = Lista_de_apostas

soma = n1 + n2 + n3 + n4 + n5 + n6 + n7

while n2 >= n1 and n2 <= n3:
    for x in range (n5 >= n4 and n5 <= n6):
        for x in range ( n7 >= n6 and n7 <= 9):
            if soma % 7 != 0 or soma % 13 != 0:
                soma = n1 + n2 + n3 + n4 + n5 + n6 + n7
                print ("{n1} - {n2} - {n3} - {n4} - {n5} - {n6} - {n7}")

print("Lista de apostas:")
print("{} - {} - {} - {} - {} - {} - {}".format(n1, n2, n3, n4, n5, n6, n7))