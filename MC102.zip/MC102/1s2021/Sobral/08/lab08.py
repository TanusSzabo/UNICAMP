###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 8 - O Desafio da Palavra Escondida
# Nome: Bruno Sobral Ferreira Ruzzi
# RA: 145537
###################################################

# Leitura de dados
prosa = int(input())
palavras_da_alma = []
for i in range(prosa):
    palavras_pequenas = input().lower().split()
    for j in range(len(palavras_pequenas)):
        palavras_da_alma.append(palavras_pequenas[j])

cellbit = input()


# Verificação da palavra no texto
notpron = 0
tente_me_enganar = []
vem_nenem = []
for i in range(len(palavras_da_alma)):
    if palavras_da_alma[i].find(cellbit[notpron]) >= 0:
        tente_me_enganar.append(i+1)
        vem_nenem.append(palavras_da_alma[i].find(cellbit[notpron]) + 1)
        notpron = notpron + 1
    if notpron >= len(cellbit):
        break


# Impressão da saída do programa
if notpron >= len(cellbit):
    print("Palavra encontrada")
    for i in range(len(cellbit)):
        print("{0}: palavra {1}, letra {2}".format(cellbit[i], tente_me_enganar[i], vem_nenem[i]))
else:
    print("Palavra nao encontrada")
