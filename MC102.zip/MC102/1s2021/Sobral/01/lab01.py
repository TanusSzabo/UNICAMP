###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 00 - Aritmetica com Inteiros
# Nome: Bruno Sobral Ferreira Ruzzi
# RA: 145537
###################################################

a = int(input())
b = int(input())
c = int(input())

print("a =", a)
print("b =", b)
print("c =", c)
print("a + b + c =", a + b + c)
print("a - b - c =", a - b - c)
print("a * b * c =", a * b * c)
print("a ** c =", a ** c)
print("b // c =", b // c)
print("b % c =", b % c)