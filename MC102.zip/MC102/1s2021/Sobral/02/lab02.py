###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 00 - Aritmetica com Inteiros
# Nome: 
# RA:
###################################################

# Leitura de dados
dist_a_b = float(input())
vel_t1 = float(input())
t_b_c = float(input())
dist_b_c = float(input())
vel_t2 = float(input())
t_show =  float(input())
chegou = False # Variável em relação à chegada

t_viagem_a_b = 60*dist_a_b/vel_t1   # Tempo de viagem do trem entre A e B em min
t_viagem_b_c = 60*dist_b_c/vel_t2   # Tempo de viagem do trem entre B e C em min
t_viagem = t_b_c + t_viagem_b_c  # Tempo de viagem total em min

chegueiB = t_viagem_a_b <= t_b_c  # True ou False
chegueiShow = t_viagem <= t_show  # True ou False

# Chegar antes do trem 2 partir e Chegar antes do show começar
chegou = chegueiB and chegueiShow

print(chegou)