###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 2 - O Grande Show
# Nome: 
# RA: 
###################################################

# Leitura de dados

dist_a_b = int(input()) #distância da cidade atual (cidade A) para a segunda cidade (cidade B), em km (valor inteiro).
vel_t1 = float(input()) #velocidade do trem que fará a viagem da cidade A para a cidade B, em km/h (valor real).
t_b_c = int(input()) #tempo de partida do trem da cidade B para sua cidade natal (cidade C), em relação ao instante de saída do primeiro trem, em minutos (valor inteiro).
dist_b_c = int(input()) #distância da cidade B para a cidade C, em km (valor inteiro).
vel_t2 = float(input()) #velocidade do trem que fará a viagem da cidade B para a cidade C, em km (valor inteiro).
t_show =  int(input()) #tempo para o início do show, a partir do instante de saída do primeiro trem, em minutos (valor inteiro).


# Cálculo do tempo de chegada na cidade B e de chegada na cidade C 

t_a_b = 60 * dist_a_b / vel_t1   # Tempo de viagem do trem a_b
t_total = t_b_c + (60*dist_b_c/vel_t2)  # Tempo de viagem total


# Impressão da resposta

if (t_a_b <= t_b_c): #Testa se a pessoa chegou em B antes de partir o trem b_c
    if (t_total <= t_show): #Testa se a pessoa chegou em C antes do show começar
        print("True")
    else:
        print("False")

else:
    print("False")