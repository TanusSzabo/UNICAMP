###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 2 - O Grande Show
# Nome: 
# RA: 
###################################################

dist_a_b = float(input())
vel_t1 = float(input())
t_b_c = float(input())
dist_b_c = float(input())
vel_t2 = float(input())
t_show =  float(input())

print( (60*dist_a_b/vel_t1 <= t_b_c) and ((t_b_c + (60*dist_b_c/vel_t2)) <= t_show) )
