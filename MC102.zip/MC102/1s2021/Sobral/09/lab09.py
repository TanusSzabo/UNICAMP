#####################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 9 - Magic: Trocando Cartas
# Nome: Bruno Sobral Ferreira Ruzzi
# RA: 145537
###################################################

# Leitura de dados

baralho_do_meu_avo = []
coracao_das_cartas = []

n = int(input())
for i in range(n):
    cartas = input().split()
    baralho_do_meu_avo.append(cartas[0])
    baralho_do_meu_avo.append(int(cartas[1]))

m = int(input())
for j in range(m):
    cartas = input().split()
    coracao_das_cartas.append(cartas[0])
    coracao_das_cartas.append(int(cartas[1]))


# Processamento das trocas

trocas = []

while True:
    hora_do_duelo = input()
    if hora_do_duelo == '---':
        break

    kaiba, yugi = hora_do_duelo.split()
    if yugi in baralho_do_meu_avo:
        if yugi in coracao_das_cartas:
            if baralho_do_meu_avo[baralho_do_meu_avo.index(yugi) + 1] > coracao_das_cartas[coracao_das_cartas.index(yugi) + 1]:
                trocas.append(True)
                baralho_do_meu_avo[baralho_do_meu_avo.index(yugi) + 1] -= 1
                if kaiba in baralho_do_meu_avo:
                    baralho_do_meu_avo[baralho_do_meu_avo.index(kaiba) + 1] += 1
                else:
                    baralho_do_meu_avo.append(kaiba)
                    baralho_do_meu_avo.append(1)
            else:
                trocas.append(False)
        elif baralho_do_meu_avo[baralho_do_meu_avo.index(yugi) + 1] > 0:
            trocas.append(True)
            baralho_do_meu_avo[baralho_do_meu_avo.index(yugi) + 1] -= 1
            if kaiba in baralho_do_meu_avo:
                baralho_do_meu_avo[baralho_do_meu_avo.index(kaiba) + 1] += 1
            else:
                baralho_do_meu_avo.append(kaiba)
                baralho_do_meu_avo.append(1)
        else:
            trocas.append(False)
    else:
        trocas.append(False)


# Processamento se as cartas desejadas foram obtidas

exodia_o_proibido = True

for i in range(len(trocas)):
    if trocas[i]:
        print('TROCA REALIZADA!')
    else:
        print('TROCA NAO REALIZADA!')

for j in range(m):
    if coracao_das_cartas[2*j] in baralho_do_meu_avo:
        if baralho_do_meu_avo[baralho_do_meu_avo.index(coracao_das_cartas[2*j]) + 1] >= coracao_das_cartas[2*j + 1]:
            exodia_o_proibido = True
        else:
            exodia_o_proibido = False
    else:
        exodia_o_proibido = False

    if exodia_o_proibido == False:
        print("JOAO NAO CONSEGUIU AS CARTAS DESEJADAS!")
        break

if exodia_o_proibido:
    print("JOAO CONSEGUIU AS CARTAS DESEJADAS!")
