###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 6 - Plataforma
# Nome: 
# RA: 
###################################################

"""   Enunciado forçado:
   Você quer programar um jogo simples de plataforma. 
   Nesse jogo você receber uma linha com números que vai definir a plataforma, 
seguido de uma posição que é onde seu personagem vai iniciar na plataforma 
(Começando a contagem da posição em 1, e não na 0, porque esse lab foi escrito por um cuzão).
   
   O jogo funciona assim:
   O número que estiver escrito na plataforma vai definir o salto que seu personagem vai dar,
números positivos são saltos para a direita e números negativos são saltos para a esquerda.
   
   Assim, o jogo acaba quando seu personagem cair para a direita ou para a esquerda da plataforma,
ou quando ele entrar em looping, ou seja, quando cair em uma casa que já caiu antes.

   Com isso, você deve imprimir os índices da plataforma que seu personagem passar, 
e terminar dizendo se ele caiu pra esquerda, pra direita, ou entrou em loop.

   Teste 1:
1 3 -2 3 5 -1 -1 2 4 -4
2
   Saida 1:
2
5
10
6
loop

    Teste 2:
1 1 1 1 1 1 1 1
1
    Saída 2:
1
2
3
4
5
6
7
8
direita

    Teste 3:
1 5 -3 4 -2 -4 2 -2
8
    Saída 3:
8
6
2
7
direita
"""


# Leitura de dados

plataforma = [int(i) for i in input().split()]  # Lista que vai receber a entrada da plataforma
i = int(input())   # numero da posição que o personagem vai ta  (1 a mais que o índice da lista)

print(i)   # printa a primeira posição

# Processamento do jogo

while True:
    pos = i + plataforma[i-1]   # Calcula a nova posição pelo valor que tiver no indice atual da plataforma
    plataforma[i-1] = 'X'       # Muda o valor da plataforma pra saber se eu passar por essa posição de novo
    
    if pos > len(plataforma):   # Se a posição estiver além do tamanho da lista
        print("direita")        # eu cai pra direita
        break                   # sai da repetição
    
    if pos <= 0:                # Se a posição for anterior à 0, vulgo ao começo da lista
        print("esquerda")       # eu cai pra esquerda
        break                   # sai da repetição
    
    if plataforma[pos-1] == 'X':  # Se na posição que estivermos tiver um valor 'X'
        print("loop")             # significa que já passei por aqui, então cai em loop
        break                     # sai da repetição
    
    i = pos   # Se a gente não caiu em nenhuma das condições a cima, o jogo continua, atualizo a posição
    print(i)  # printo minha nova posição e vamos pra próxima repetição.