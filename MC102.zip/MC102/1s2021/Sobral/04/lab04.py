###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 4 - Magic: The Gathering
# Nome: Bruno Sobral Ferreira Ruzzi
# RA: 145537
###################################################

# Leitura do orçamento, do valor do booster e da quantidade de cartas desejadas

X = float(input())
B = float(input())
D = int(input())

# Leitura da sequência de cartas

quantidade_boosters = int(X/B)
quantidade_cartas = 0
i = 0

while quantidade_boosters > i:
    i = i + 1
    carta = int(input())
    if carta == 3 or carta == 5:
        quantidade_cartas = quantidade_cartas + 1
        if quantidade_cartas >= D:
            quantidade_boosters = i

total_gasto = quantidade_boosters * B
total_restante = X - total_gasto

# Impressão das informações de saída

print("ORCAMENTO: {:.2f} REAIS".format(X))
print("VALOR DO BOOSTER: {:.2f} REAIS".format(B))
print("TOTAL GASTO: {:.2f} REAIS".format(total_gasto))
print("TOTAL RESTANTE: {:.2f} REAIS".format(total_restante))
print("QUANTIDADE DE BOOSTERS COMPRADOS: {}".format(quantidade_boosters))
print("QUANTIDADE DESEJADA DE CARTAS DA COR VERDE OU DA COR PRETA: {}".format(D))
print("QUANTIDADE OBTIDA DE CARTAS DA COR VERDE OU DA COR PRETA: {}".format(quantidade_cartas))

if quantidade_cartas >= D:
    print("JOAO CONSEGUIU MONTAR SEU NOVO DECK!")
else:
    print("JOAO NAO CONSEGUIU MONTAR SEU NOVO DECK!")

