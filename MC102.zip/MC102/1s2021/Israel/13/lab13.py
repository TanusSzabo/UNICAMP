###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 13 - Super Trunfo
# Nome: 
# RA: 
###################################################

# Leitura das cartas

N = int( input() )    # Numero de cartas que terá o baralho
baralho = []          # matriz que armazenara as cartas e seus atributos
baralho.append(input().split())  # adiciona a linha título

for i in range(N):      # para toda carta
    entrada = input().split()  # é pego a entrada com nome da carta e atributos
    linha = []                 # linha que armazenará o nome e atributo das cartas bonitinhos
    linha.append( entrada[0] ) # adiciona o nome sem tentar forçar int nele (porque daria erro)
    for j in range( 1, len(entrada) ):   # para todos atributos (que não o nome da carta)
        linha.append( int(entrada[j]) )  # adiciona o atributo como inteiro n linha

    baralho.append(linha)  # adiciona a linha ao baralho

prioridades = input().split()  # linha de prioridades para insercao



# Ordenação das cartas


# melhor sistema de ordenamento, mas o lab que o "numero de inserções", então tem que usar o insertion sort mesmo...
# mas vou deixar aqui de birra
def matrix_bubble_sort(matriz, coluna):
    linha_inicio = 1
    for i in range(linha_inicio, len(matriz)):
        for j in range(len(matriz)-1, i, -1):
            if matriz[j-1][coluna] < matriz[j][coluna]:
                matriz[j], matriz[j-1] = matriz[j-1], matriz[j]

    return matriz

# O método de ordenamento mais paia que existe, falo mesmo
def matrix_insertion_sort(matriz, coluna):
    """
    O algorítmo de inserção é relativamente simples, como "inserir" as cartas no baralho 1 por 1:
    Começando da segunda carta, você vai inserindo as cartas subsequentes nas posições ordenadas delas.
    Para isso, fazemos a comparação com as cartas anteriores, se elas forem menores (já que queremos ordenar
    do maior pro menor), fazemos a troca, isso até atingir a primeira carta, ou até aparecer uma carta que seja maior
    que a que pretendemos inserir.
    e.g. [1, 3, 2, 1, 4]
    começamos com o vetor [1] e colocamos o segundo item, 3. Este é maior que o 1, logo inserimos ele antes do 1
    [3, 1]
    o próximo item é o 2, esse é maior que o 1, mas menor que o 3, então inserimos ele entre os dois
    [3, 2, 1]
    o próximo item é o 1, esse não é maior que o próprio 1, então "não inserimos" ele (colocamos na ultima posição mesmo)
    [3, 2, 1, 1]
    por ultimo o 4, esse é maior que 1, maior que o outro 1, maior que 2, maior que 3, então inserimos ele na primeira posição
    [4, 3, 2, 1, 1]
    no final, 3 dos 4 itens a mais que o primeiro foram inseridos no meio do baralho, logo houve 3 inserções
    """

    linha_inicio = 1  # devido à eu ter adicionado a "linha titulo" na matriz, eu forço o inicio do ordenamento 
    trocas = 0        # número de inserções realizadas
    for i in range(linha_inicio+1, len(matriz)):  # para todos itens após o primeiro (além do título)
        pivo = matriz[i]  # seguramos o pivo
        j = i-1           # olhamos para a posição anterior desse pivo
        insercao = True   # variável para verificar se a carta foi inserida no meio

        # Enquanto não chegar no início da lista e os itens anteriores forem menores que o item a inserir.
        # É importante ver que, se o programa entrar aqui, significa que a carta será inserida no meio de outras
        # caso não entre aqui, a carta já está na sua posição perfeita
        while j>=linha_inicio and pivo[coluna] > matriz[j][coluna]:
            matriz[j+1] = matriz[j]  # vai passando os itens anteriores pra frente pra dar espaço pro item a inserir
            j -= 1                   # diminui o contador pra ver o item anterior ao que ta vendo agora
            if insercao:             # testa se é a primeira tentativa de inserir a carta
                trocas += 1          # aumenta 1 no contador
                insercao = False     # já contabilizando a inserção da carta, pra essa não contará mais
        matriz[j+1] = pivo  # "insere" a carta na posição final que achou a posição top!

    return trocas  # retorna a quantidade de inserções realizadas

trocas = 0  # variável que contara a quantidade de inserções totais
for k in range( len(prioridades) ):                      # para todas as prioridades de ordenamento
    prior = prioridades[len(prioridades)-k-1]            # começa pela ultima (para a primeira ter mais peso)
    for i in range( len(baralho) ):                      # para todas colunas de atributos
        if prior == baralho[0][i]:                       # ve se aquela coluna é a prioridade em questão
            # print(prior, i)
            trocas += matrix_insertion_sort(baralho, i)  # chama o ordenamento com aquela coluna, adicionando a quantidade de inserções
            break                                        # quebra o for de colunas porque já achou a coluna a ordenar
    # for i in range( len(baralho) ):
        # print(baralho[i])


# Impressão dos dados

for carta in baralho:    # Para todas as cartas no baralho
  print('{:15s}'.format(carta[0]), ''.join('{:>10}'.format(atributo) for atributo in carta[1:]))  # imprime a carta certinho
print('Insercoes realizadas:', trocas)  # no final, imprime a quantidade de inserções feitas
