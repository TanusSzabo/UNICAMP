###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 12 - Processamento de Imagens
# Nome: 
# RA: 
###################################################

# Função para impressão da imagem
def imprimir_imagem(imagem):
    print("P2")    # Imprime o tipo da imagem
    print(len(imagem[0]), len(imagem))  # imprime as dimenções da imagem
    print("255")   # Imprime o valor maximo de pixel
    for i in range(len(imagem)):  # Para toda linha da matriz
        print(" ".join(str(x) for x in imagem[i]))  # imprime a linha toda


def flip_horizontal(imagem_original):
    imagem = []
    linhas = len(imagem_original)     # quantidade de linhas na imagem
    colunas = len(imagem_original[0]) # quantidade de colunas na imagem
    for i in range(linhas):           # para toda linha da imagem
        linha = []                    # variável que armazenará a linha da imagem nova 
        for j in range(colunas-1, -1, -1):  # para toda coluna indo de traz pra frente
            linha.append( imagem_original[i][j] )  # adiciona o valor na linha
        imagem.append(linha) # adiciona a linha na imagem

    return(imagem)   # retorna a imagem
            
    
def flip_vertical(imagem_original):
    imagem = []
    linhas = len(imagem_original)     # quantidade de linhas na imagem
    colunas = len(imagem_original[0]) # quantidade de colunas na imagem
    for i in range(linhas-1, -1, -1): # para toda linha indo de traz pra frente
        linha = []                    # variável que armazenará a linha da imagem nova 
        for j in range(colunas):      # para toda coluna da imagem
            linha.append( imagem_original[i][j] )  # adiciona o valor na linha
        imagem.append(linha) # adiciona a linha na imagem

    return(imagem)   # retorna a imagem
    

def shift_vertical(imagem_original, x):
    imagem = []
    linhas = len(imagem_original)     # quantidade de linhas na imagem
    colunas = len(imagem_original[0]) # quantidade de colunas na imagem
    for i in range(-x, linhas-x, 1):  # para toda linha defasada em -x ( começa do [final-x] )
        linha = []                    # variável que armazenará a linha da imagem nova 
        for j in range(colunas):      # para toda coluna da imagem
            linha.append( imagem_original[i][j] )  # adiciona o valor na linha
        imagem.append(linha) # adiciona a linha na imagem

    return(imagem)   # retorna a imagem
    

def shift_horizontal(imagem_original, x):
    imagem = []
    linhas = len(imagem_original)     # quantidade de linhas na imagem
    colunas = len(imagem_original[0]) # quantidade de colunas na imagem
    for i in range(linhas):           # para toda linha da imagem
        linha = []                    # variável que armazenará a linha da imagem nova 
        for j in range(-x, colunas-x, 1):   # para toda coluna defasada em -x ( começa do [final-x] )
            linha.append( imagem_original[i][j] )  # adiciona o valor na linha
        imagem.append(linha) # adiciona a linha na imagem

    return(imagem)   # retorna a imagem
    

def crop(imagem_original, x1, y1, x2, y2):
    imagem = []
    linhas = len(imagem_original)     # quantidade de linhas na imagem
    colunas = len(imagem_original[0]) # quantidade de colunas na imagem
    for i in range(x1-1, x2, 1):      # para toda linha começando em x1 e terminando em x2
        linha = []                    # variável que armazenará a linha da imagem nova 
        for j in range(y1-1, y2, 1):  # para toda coluna começando em y1 e terminando em y2
            linha.append( imagem_original[i][j] )  # adiciona o valor na linha
        imagem.append(linha) # adiciona a linha na imagem

    return(imagem)   # retorna a imagem
    

def shrink(imagem_original):
    imagem = []
    linhas = len(imagem_original)      # quantidade de linhas na imagem
    colunas = len(imagem_original[0])  # quantidade de colunas na imagem
    for i in range(0, linhas, 2):      # para toda linha pulando de 2 em 2
        linha = []                     # variável que armazenará a linha da imagem nova 
        for j in range(0, colunas, 2): # para toda coluna pulando de 2 em 2
            maximo = 0                 # variável que armazenará o máximo dos 4 valores numa matriz 2x2

            for n in range(2):         # para os dois valores de linhas a partir daquela linha
                for m in range(2):     # para os dois valores de colunas a partir daquela coluna
                    if imagem_original[i+n][j+m] > maximo: # testa se o valor do pixel é maior que o maximo armazenado
                        maximo = imagem_original[i+n][j+m] # se for, temos um novo máximo
                        
            linha.append( maximo )  # dentre os 4 valores, é armazenado apenas o maior
        imagem.append(linha) # adiciona a linha na imagem

    return(imagem)   # retorna a imagem

# ------------------------------------------------------------------------------------------------------------- #
# ---------------------------------------------- FUNÇÕES BONUS ------------------------------------------------ #
# ------------------------------------------------------------------------------------------------------------- #

# Função que retorna o valor da mediana de uma lista 
def mediana(lista):
    lista_ordenada = sorted(lista)   # ordena a lista
    elemento_central = len(lista_ordenada) // 2  # pega a metade dela
    if len(lista) % 2 == 1:   # se o valor for impar: 
        return lista_ordenada[elemento_central]  # a mediana é o valor central
    else:   # senão:
        #retorna a parte inteira da média entre os elementos centrais
        return (lista_ordenada[elemento_central-1] + lista_ordenada[elemento_central]) // 2

def filtro_negativo(imagem_original, maximo):
    imagem = []
    linhas = len(imagem_original)      # quantidade de linhas na imagem
    colunas = len(imagem_original[0])  # quantidade de colunas na imagem
    for i in range(linhas):            # para toda linha da imagem
        linha = []                     # variável que armazenará a linha da imagem nova 
        for j in range(colunas):       # para toda coluna na imagem
            linha.append( maximo - imagem_original[i][j] )  # adiciona o valor do pixel negativo (maximo - valor do pixel)
        imagem.append(linha) # adiciona a linha na imagem

    return(imagem)   # retorna a imagem

def filtro_mediana(imagem):
    imagemnova = []
    for i in range(0,len(imagem)):                   # para toda linha da imagem
        imagemlinha = []                             # variável que armazenará a linha da imagem nova 
        for j in range(0,len(imagem[0])):            # para toda coluna na imagem
            lista = []                               # variável que armazenará a lista dos 9 valores ao redor do pixel
            for p in range(i-1, i+2):                # para cada uma das 3 linhas ao redor do pixel
                if p < 0 or p > len(imagem)-1:       # se os valores ultrapassarem a imagem, passamos
                    pass
                else:                                # senão:
                    for q in range(j-1, j+2):        # para cada uma das 3 colunas ao redor do pixel
                        if q < 0 or q > len(imagem[0])-1:    # se os valores ultrapassarem a imagem, passamos
                            pass
                        else:                                # senão:
                            lista.append(int(imagem[p][q]))  # adicionamos o valor na lista de 9 valores
                                
            imagemlinha.append(mediana(lista)) # adicionamos a mediana dos 9 valores ao redor do pixel na linha
        imagemnova.append(imagemlinha)         # adiciona a linha na imagem

    return imagemnova   # retorna a imagem

def convolucao(imagem, M, D, maximo):
    imagemnova = []

    for i in range(1,len(imagem)-1):                      # para toda linha da imagem
        imagemlinha = []                                  # variável que armazenará a linha da imagem nova 
        for j in range(1,len(imagem[0])-1):               # para toda coluna na imagem
            lista = 0                                     # variável que armazenará a soma dos 9 valores ao redor do pixel
            for p in range(i-1, i+2):                     # para cada uma das 3 linhas ao redor do pixel
                if p < 0 or p > len(imagem)-1:            # se os valores ultrapassarem a imagem, passamos
                    pass
                else:                                     # senão:
                    for q in range(j-1, j+2):             # para cada uma das 3 colunas ao redor do pixel
                        if q < 0 or q > len(imagem[0])-1: # se os valores ultrapassarem a imagem, passamos
                            pass
                        else:                             # senão:
                            # adicionamos o valor pixel escalonado pelo valor da matriz de covolução
                            lista = lista + int(imagem[p][q])*M[p-i+1][q-j+1]

            lista = int(lista/D)  # dividimos o valor da soma pelo peso da matriz  
            if lista < 0:         # se o valor for negativo, deixamos o mínimo 0
                lista = 0
            if lista > maximo:    # se o valor for maior que o máximo valor de pixel (255), deixamos o valor máximo
                lista = maximo                  
            imagemlinha.append(lista)  # adicionamos o valor da covolução na linha
        imagemnova.append(imagemlinha) # adiciona a linha na imagem

    return imagemnova   # retorna a imagem



# leitura da imagem
tipo = input() #P2 - linha a ser ignorada

m, n = [int(x) for x in input().split()]  # tamanho da imagem (linha, coluna)

valor_maximo_do_pixel = int( input() ) #255 - linha a ser ignorada

imagem_original = []
for i in range(n):                             # para toda linha da imagem
    linha = [int(x) for x in input().split()]  # adicionamos a linha de entrada toda na imagem
    imagem_original.append(linha)



# leitura da operação e parâmetros

filtro = input()       # entrada que ditará o filtro

if filtro == 'flip':   # se a entrada for flip
    direcao = input()  # precisa saber se será flip horizontal ou vertical
    if direcao == 'horizontal':
        imagem = flip_horizontal(imagem_original)  # chama a função flip_horizontal
    elif direcao == 'vertical':
        imagem = flip_vertical(imagem_original)    # chama a função flip_vertical

elif filtro == 'shift':   # se a entrada for shift
    direcao = input()     # precisa saber se será shift horizontal ou vertical
    quantidade = int( input() )  # e outra pra saber de quantos pixels será o shift
    if direcao == 'horizontal':
        imagem = shift_horizontal(imagem_original, quantidade)  # chama a função shift_horizontal
    elif direcao == 'vertical':
        imagem = shift_vertical(imagem_original, quantidade)    # chama a função shift_vertical

elif filtro == 'crop':        # se a entrada for crop
    x1, y1 = input().split()  # precisa saber qual o ponto inicial...
    x1 = int(x1)
    y1 = int(y1)
    x2, y2 = input().split()  # e qual o ponto final do crop
    x2 = int(x2)
    y2 = int(y2)
    imagem = crop(imagem_original, x1, y1, x2, y2) # chama a função crop

elif filtro == 'shrink':    # se a entrada for shrink
    imagem = shrink(imagem_original) # chama a função shrink

# ------------------------------------------------------------------------------------------------------------- #
# ---------------------------------------------- FUNÇÕES BONUS ------------------------------------------------ #
# ------------------------------------------------------------------------------------------------------------- #

if filtro == "negativo":       # se a entrada for negativo
    imagem = filtro_negativo(imagem_original, valor_maximo_do_pixel) # chama a função negativo

elif filtro == "mediana":      # se a entrada for mediana
    imagem = filtro_mediana(imagem_original) # chama a função mediana

elif filtro == "blur":      # se a entrada for blur
    # Chama a função de convolução com a matriz de convolução
    # | 1 1 1 |
    # | 1 1 1 |
    # | 1 1 1 |
    #
    # e peso 9
    M = [[1,1,1],[1,1,1],[1,1,1]]
    D = 9
    imagem = convolucao(imagem_original, M, D, valor_maximo_do_pixel)
    
elif filtro == "sharpen":      # se a entrada for sharpen
    # Chama a função de convolução com a matriz de convolução
    # | 0 -1  0 |
    # |-1  5 -1 |
    # | 0 -1  0 |
    #
    # e peso 1
    M = [[0,-1,0],[-1,5,-1],[0,-1,0]]
    D = 1
    imagem = convolucao(imagem_original, M, D, valor_maximo_do_pixel)

elif filtro == "edge-detect":      # se a entrada for edge-detect
    # Chama a função de convolução com a matriz de convolução
    # |-1 -1 -1 |
    # |-1  8 -1 |
    # |-1 -1 -1 |
    #
    # e peso 1
    M = [[-1,-1,-1],[-1,8,-1],[-1,-1,-1]]
    D = 1
    imagem = convolucao(imagem_original, M, D, valor_maximo_do_pixel)



# impressão da imagem final

imprimir_imagem(imagem)   # chama a função imprimir_imagem
