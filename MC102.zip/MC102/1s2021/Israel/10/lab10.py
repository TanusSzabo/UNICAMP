###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 10 - Caça ao Tesouro
# Nome: 
# RA: 
###################################################


# Leitura da matriz

mapa = []                          # variável que vai guardar o mapa
tamanho_mapa = 8                   # tamanho do mapa (8x8)
for i in range(tamanho_mapa):      # para ler as 8 linhas referentes ao mapa
    mapa.append( input().split() ) # adiciona as linhas com split() para ter posições linha, coluna

n_sensores = int( input() )        # número de sensores
alcance = int( input() )           # alcance dos sensores (pegam em cruz)
tesouros = 0                       # contador de tesouros encontrados


"""
        Comentário:
        A partir daqui será repetido o algorítmo de procura para todos os sentidos:
        Começando da posição inicial, vera todas as posições seguindo num determinado sentido até o alcance
        parando se chegar num limite do mapa, ou parando ao encontrar uma barreira

        Exemplo:
        (5, 4), alcance 3, barreira (5,6)            
            0 1 2 3 4 5 6 7
        0 . . . . . . . .
        1 . . . . . . . .
        2 . . . . X . . .
        3 . . . . X . . .
        4 . . . . X . . .
        5 . X X X X X o . (parado pela barreira 'o')
        6 . . . . X . . .
        7 . . . . X . . .
            (parado pelo limite do campo)
"""

for i in range(n_sensores):                     # para todos sensores
    x, y = [ int(k) for k in input().split() ]  # lê-se a posição do sensor

    # Leste ( sentido positivo da linha )
    for j in range(alcance + 1):   # 0, 1, 2, ..., alcance
        # adiciona-se o valor positivo ou negativo na posição
        linha = x + j
        coluna = y
        if linha >= tamanho_mapa or linha < 0 or coluna >= tamanho_mapa or coluna < 0:  # se a posição ultrapassa o mapa
            break                                                                       # para a contagem na direção
        elif mapa[linha][coluna] == 'o':   # se naquela posição do mapa tiver uma barreira 'o' para a contagem na direção
            break
        elif mapa[linha][coluna] == 'x':   # se naquela posição do mapa tiver um tesouro 'o'
            tesouros += 1                  # adiciona 1 no contador de tesouro
            mapa[linha][coluna] = '.'      # muda o valor para nada '.', "pegando" o tesouro e
                                           # e impedindo que pegue esse novamente

    # Oeste ( sentido negativo da linha )
    for j in range(alcance + 1):
        linha = x - j
        coluna = y
        if linha >= tamanho_mapa or linha < 0 or coluna >= tamanho_mapa or coluna < 0:  
            break
        elif mapa[linha][coluna] == 'o':
            break
        elif mapa[linha][coluna] == 'x':
            tesouros += 1
            mapa[linha][coluna] = '.'

    # Norte ( sentido positivo da coluna )
    for j in range(alcance + 1):
        linha = x
        coluna = y + j
        if linha >= tamanho_mapa or linha < 0 or coluna >= tamanho_mapa or coluna < 0:  
            break
        elif mapa[linha][coluna] == 'o':
            break
        elif mapa[linha][coluna] == 'x':
            tesouros += 1
            mapa[linha][coluna] = '.'

    # Sul ( sentido positivo da coluna )
    for j in range(alcance + 1):
        linha = x
        coluna = y - j
        if linha >= tamanho_mapa or linha < 0 or coluna >= tamanho_mapa or coluna < 0:  
            break
        elif mapa[linha][coluna] == 'o':
            break
        elif mapa[linha][coluna] == 'x':
            tesouros += 1
            mapa[linha][coluna] = '.'


if tesouros == 0: # se a contagem de baús for 0
    print( "Nenhum bau encontrado." )
else:  # senão, foi encontrado baús
    print( "{} bau(s) encontrado(s).".format(tesouros) )

    