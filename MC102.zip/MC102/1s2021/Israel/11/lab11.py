###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 11 - Jogo da Similaridade Máxima
# Nome:
# RA:
###################################################

"""
Esta função recebe quatro parâmetros: 
 - linha: indíce de uma linha da matriz maior
 - coluna: indice de uma coluna da matriz maior
 - maior: matriz quandrada onde deve ser procurado um padrão 
 - menor: matriz quadrada com um padrão a ser encontrado

A função deve retornar o grau de similaridade entre a submatriz
da matriz maior que começa na posição definida pelos parâmetros 
linha e coluna e a matriz menor
"""
def calcula_similaridade(linha, coluna, maior, menor):  # essa função só será lida quando/se chamada no texto
    m_menor = len(menor)  # Tamanho da matriz menor
    m_maior = len(maior)  # Tamanho da matriz maior
    quadrados_iguais = 0  # contador de quadrados iguais
    quadrados_totais = 0  # contador de quadrados totais

    for i in range(m_menor):       # Para toda linha i
        for j in range(m_menor):   # e coluna j
            if menor[i][j] == maior[i+linha][j+coluna]:  # testa se o aquele valor da matriz menor é igual da maior
                quadrados_iguais += 1                    # se for adiciona 1 no contador de quadrados iguais
                
            quadrados_totais +=1  # já para todos os casos, aumentamos 1 no contador de quadrados totais

    similaridade = 100 * (quadrados_iguais / quadrados_totais)  # similaridade em %
    # print(linha, coluna, similaridade)  # caso queira ver para todo caso a posição e similaridade

    return similaridade   # a função então retorna o valor de similaridade encontrada naquela posição
    


# Leitura das matrizes

n_maior = int( input() )  # tamanho do quadrado maior
maior = []                # lista que guardará a matriz maior
for n in range(n_maior):  # para cada linha da matriz maior
    maior.append( input().split() )  # adiciona o input representando a linha splitada

n_menor = int( input() )  # tamanho do quadrado menor
menor = []                # lista que guardará a matriz menor
for n in range(n_menor):  # para cada linha da matriz menor
    menor.append( input().split() )  # adiciona o input representando a linha splitada



# Cálculo da submatriz de similaridade máxima

pos_maxima = [0, 0]      # variável que guardará a posição onde encontrar um máximo
similaridade_maxima = 0  # variável que guardará a similaridade máxima

for i in range(n_maior):     # Para toda linha i
    for j in range(n_maior): # e coluna j da matriz maior
        linha = i              # a linha é i
        coluna = j             # a coluna é j
        pos = [linha, coluna]  # a respectiva posição é [linha, coluna]

        # se a matriz menor na respectiva posição não ultrapassar o limite da matriz maior
        if linha + n_menor <= n_maior and coluna + n_menor <= n_maior:
            similaridade = calcula_similaridade(linha, coluna, maior, menor)  # chamamos a função de calculo de similaridade
            if similaridade > similaridade_maxima:  # se a similaridade for maior que a previamente guardada
                similaridade_maxima = similaridade  # temos uma nova similaridade máxima
                pos_maxima = pos                    # com uma respectiva posição máxima



# impressão da similaridade máxima

print("Posição: ({0},{1})".format(pos_maxima[0], pos_maxima[1]))  # imprimimos a posição
print("Similaridade máxima: {:.2f}%".format(similaridade_maxima)) # imprimimos a similaridade máxima