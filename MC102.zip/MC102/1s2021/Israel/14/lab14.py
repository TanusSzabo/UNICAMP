###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 14 - Caça-Números
# Nome: 
# RA: 
###################################################

"""
Esta função recebe como parâmetro uma matriz, uma posição inicial na
matriz determinada pelos parâmetros linha e coluna e um padrão que
deve ser buscado em todas as direções (norte, sul, leste, oeste,
nordeste, sudeste, noroeste e sudoeste) a partir da posição inicial.
Caso o padrão seja encontrado a partir da posição inicial a função
deve retornar o valor True. Caso contrário, a função de retornar o
valor False.
"""
def busca_padrao(matriz, linha, coluna, padrao):
    # Teste para as letras relacionadas a números e se suas casas tem um número que corresponda a esse:
    if padrao[0] == 'A':
        letra = True  # Any: Qualquer número
    elif padrao[0] == 'E' and (matriz[linha][coluna]%2 == 0):
        letra = True  # Even: números pares
    elif padrao[0] == 'O' and (matriz[linha][coluna]%2 == 1):
        letra = True  # Odd: números impares
    elif padrao[0] == 'C' and (matriz[linha][coluna] == 4 or matriz[linha][coluna] == 6 or matriz[linha][coluna] == 8 or matriz[linha][coluna] == 9):
        letra = True  # Composite: números compostos (4, 6, 8, 9)
    elif padrao[0] == 'P' and (matriz[linha][coluna] == 2 or matriz[linha][coluna] == 3 or matriz[linha][coluna] == 5 or matriz[linha][coluna] == 7):
        letra = True  # Prime: Números primos (2, 3, 5, 7) 
    elif padrao[0] == 'S' and (matriz[linha][coluna] == 1):
        letra = True  # Singular: só o 1
    elif padrao[0] == 'T' and (matriz[linha][coluna]%3 == 0):
        letra = True  # Three: Múltiplos de 3
    else:
        letra  = False


    if letra:  # Se o número da casa corresponder ao que a letra quer:
        
        if len(padrao) == 1:  # se o padrão só tiver essa ultima letra, chegamos ao final
            return True       # retornamos verdadeiro

        else:                 # senão, ainda temos que procurar mais padroes
            for i in range(-1, 2):     # (-1, 0, 1)
                for j in range(-1, 2): # (-1, 0, 1)
                    recursao = False   # Variável que vai ditar se encontrou um padrão em alguma direção
                    # se o valor não for (0,0) e a casa [linha+i][coluna+j] estiver dentro da matriz
                    if (i != 0 or j != 0) and (0 <= linha+i < len(matriz)) and (0 <= coluna+j < len(matriz[0])): 
                        """
                        Chamamos a função em recursão com a nova posição ao redor da que está agora, com a string de
                        padrões sem o primeiro item. Assim, a cada recursão, diminuimos o tamanho em 1, até chegar no ultimo
                        padrão a procurar, ou no meio algum dos números não estar dentro do padrão.
                        """
                        recursao = busca_padrao(matriz, linha+i, coluna+j, padrao[1:])
                        
                    if recursao:    # se em qualquer uma das posições encontrar uma resposta verdadeira 
                        return True # retorna verdadeiro (aqui o for vai quebrar porque vai sair da função)

            if recursao == False:  # se nenhuma das posições foi encontrado verdadeiro
                return False       # retorna falso

    else:             # Se a o número da casa não corresponder ao padrão que a letra quer
        return False  # retorna falso

    

# Leitura da matriz

matriz = []  # variável que vai guardar a matriz de números

while True:
    entrada = input().split()  # entrada splitada
    if entrada[0].isdigit():   # se a entrada tiver números
        matriz.append([int(x) for x in entrada])  # é parte da matriz e adicionamos a essa
    else:  # senão, é a entrada com os padrões a serem encontrados
        padroes = entrada[0]  # guardamos esses padrões
        break  # quebramos o while

# Processamento da busca na matriz

posicoes = []      # variável que vai guardar as posições que encontrarem padroes corretos
n = len(matriz)    # linhas na matriz
m = len(matriz[0]) # colunas na matriz

for i in range(n):     # para toda linha da matriz
    for j in range(m): # para toda coluna da matriz
        if busca_padrao(matriz, i, j, padroes): # vemos se naquela posição ira encontrar todos os padrões
            posicoes.append([i+1, j+1])   # se sim, adicionamos a posição na lista de posições top


# Impressão das posições iniciais (linha e coluna)

if len(posicoes) == 0:   # se a lista não tiver nenhum item
    print("Nenhum padrao encontrado!")
else:    # senão
    print(("Posicoes: " + " ".join([str((linha, coluna)) for linha, coluna in posicoes])).strip())
