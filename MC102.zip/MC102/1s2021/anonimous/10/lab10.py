###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 10 - Caça ao Tesouro
# Nome: 
# RA: 
###################################################

# Leitura da matriz

campo = []   # Matriz 8x8 que armazenará o campo
for i in range(8):  # Para toda linha da matriz
    campo.append(input().split())  # adiciona a linha inteira da entrada splitada

campo_visão = []   # Matriz 8x8 que armazenará o campo visível aos sensores
for i in range(8):  # Para toda linha da matriz
    campo_visão.append( [' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '] ) # adiciona a linha inteira de visão vazia

# Leitura e processamento dos sensores

num_sensores = int(input())   # número de sensores que serão colocados
alcance = int(input())        # alcance em cruz dos sensores

for i in range(num_sensores):  # Para cada um dos sensores
    linha, coluna = [int(i) for i in input().split()]  # pega a posição que foi colocado o sensor

    # variáveis que para verificar se a direção foi bloqueada por uma barreira
    direita = True
    esquerda = True
    cima = True
    baixo = True

    for j in range(alcance + 1):   # para todo ponto no alcance dos sensores
        if direita and 0 <= coluna + j <= 7:   # testa se a direção não foi bloqueada ou está fora do mapa
            campo_visão[linha][coluna + j] = campo[linha][coluna + j]  # copia o que consta no campo naquele ponto pro campo de visão
            if campo[linha][coluna + j] == 'o':  # se naquela posição tiver uma barreita
                direita = False  # é alterado a permissão dessa direção

        if esquerda and 0 <= coluna - j <= 7:   # testa se a direção não foi bloqueada ou está fora do mapa
            campo_visão[linha][coluna - j] = campo[linha][coluna - j]  # copia o que consta no campo naquele ponto pro campo de visão
            if campo[linha][coluna - j] == 'o':  # se naquela posição tiver uma barreita
                esquerda = False  # é alterado a permissão dessa direção

        if cima and 0 <= linha + j <= 7:   # testa se a direção não foi bloqueada ou está fora do mapa
            campo_visão[linha + j][coluna] = campo[linha + j][coluna]  # copia o que consta no campo naquele ponto pro campo de visão
            if campo[linha + j][coluna] == 'o':  # se naquela posição tiver uma barreita
                cima = False  # é alterado a permissão dessa direção

        if baixo and 0 <= linha - j <= 7:   # testa se a direção não foi bloqueada ou está fora do mapa
            campo_visão[linha - j][coluna] = campo[linha - j][coluna]  # copia o que consta no campo naquele ponto pro campo de visão
            if campo[linha - j][coluna] == 'o':  # se naquela posição tiver uma barreita
                baixo = False  # é alterado a permissão dessa direção
  
# Impressão da saída

baus = 0   # contador de baús encontrados
for i in range(8):      # Para toda linha i da matriz 8x8
    for j in range(8):  # e toda coluna j 
        if campo_visão[i][j] == 'x':   # se algum sensor viu um tesouro naquela posição
            baus += 1  # é aumentado 1 no valor de baús encontrados

if baus == 0:   # se nenhum baú for encontrado:
    print("Nenhum bau encontrado.")
else:           # se não:
    print(baus,"bau(s) encontrado(s).")

