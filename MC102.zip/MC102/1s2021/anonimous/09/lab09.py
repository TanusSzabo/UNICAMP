#####################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 9 - Magic: Trocando Cartas
# Nome:
# RA:
###################################################

# Leitura de dados:

cartas_para_troca = {}
n = int(input()) 
for i in range(n):
    carta, quant = input().split()   # Entrada num formato tipo 'CARD02 4'
    quant = int(quant)               # transformamos a segunda parte em um número
    cartas_para_troca[carta] = quant # adicionams no dicionário, e.g. {'CARD02': 4}

cartas_desejadas = {} 
n = int(input())
for i in range(n):
    carta, quant = input().split()       # Entrada num formato tipo 'CARD02 4'
    quant = int(quant)                   # transformamos a segunda parte em um número
    cartas_desejadas[carta] = int(quant) # adicionams no dicionário, e.g. {'CARD02': 4}


# Processamento das trocas

trocas = []   # lista que armazenará se a troca foi feita (True), ou não (False)

while True:
    entrada = input()
    if entrada == '---':    # Se a entrada for '---' é sinal pra parar de ler, assim quebramos o while
        break

    carta_amigo, carta_joao = entrada.split()  #  Se a entrada não for a '---', ela estará num formato 'CARD02 CARD04',
                                               # representando a carta que joão vai receber em troca da que ele deve dar

    """ 
    O algoritmo utilizado para testar as trocas é o seguinte:
    As cartas recebidas terão prioridades de serem contabilizadas como cartas desejadas, então se aquela carta for desejada,
    será contabilizada tirando 1 do valor respectivo, assim a carta recebida não vai parar no cartas_para_troca, mas sim
    será guardada com amor contabilizadno -1 no cartas_desejadas.

    Assim, da pra garantir que todas as cartas no cartas_para_troca estão la para serem trocadas. Portanto se a carta
    tiver no cartas_para_troca e seu valor for maior que 0, a troca será realizada! Mas, reiterando, a carta recebida
    tem prioridade de ser contabilizada no limbo das cartas_desejadas, agora se a carta recebida não for uma das 
    desejadas ou o a coleção daquela carta ja foi feita (ou seja, o contado no cartas_desejadas for igual a 0), ai a 
    carta recebida pode ser usada para a troca, sendo contabilizada no cartas_para_troca.
    """

    if carta_joao in cartas_para_troca and cartas_para_troca[carta_joao] > 0:  # Se a carta a dar tiver no baralho do joão e sua quatidade for maior que 0 
        trocas.append(True)                   # A troca é realizada
        cartas_para_troca[carta_joao] -= 1    # tiramos a carta dada do baralho do joão

        if carta_amigo in cartas_desejadas and cartas_desejadas[carta_amigo] > 0:  # Se a carta a receber estiver no baralho desejado e for maior que 0
            cartas_desejadas[carta_amigo] -= 1    # contabilizamos a carta recebida tirando 1 do contador de cartas desejadas

        else:     # Se a carta a receber não tiver no baralho de cartas desejadas 
            if carta_amigo in cartas_para_troca:  # contabilizamos a carta recebida colocando no baralho do joão, se a carta ja tiver la
                cartas_para_troca[carta_amigo] += 1  # adicionamos 1 ao valor dela
            else:                                    # se a carta não tiver no baralho ainda
                cartas_para_troca[carta_amigo] = 1   # colocamos ela com o valor inicial 1

    else:         # Se a carta para dar não está no baralho do joão, não tem como ser realizada a troca, assim:                           
        trocas.append(False) # a troca não é realizada


# Processamento se as cartas desejadas foram obtidas

for i in range( len(trocas) ): # impressão do resultado das trocas (Que poderia ser feito no meio do código, mas fica bagunçado)
    if trocas[i] == True:
        print('TROCA REALIZADA!')
    else:
        print('TROCA NAO REALIZADA!')

cartas_faltantes = 0  # contador pra ver se o contador de cartas desejadas caiu pra 0
for i in cartas_desejadas:  # para todas as cartas nesse dicionário
    cartas_faltantes += cartas_desejadas[i] # adicionamos o valor no contador

if cartas_faltantes > 0:   # se ainda faltou adiquirir alguma das cartas desejadas
    print("JOAO NAO CONSEGUIU AS CARTAS DESEJADAS!")
else:                      # senão:
    print("JOAO CONSEGUIU AS CARTAS DESEJADAS!")

