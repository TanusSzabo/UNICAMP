###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 12 - Processamento de Imagens
# Nome: 
# RA: 
###################################################

def imprimir_imagem(imagem):
    print("P2")
    print(len(imagem[0]), len(imagem))
    print("255")
    for i in range(len(imagem)):
        print(" ".join(str(x) for x in imagem[i]))


def flip_horizontal(imagem_original):
    imagem = []       # Variável que vai guardar a imagem com a operação
    for i in range( len(imagem_original) ):  # para toda linha da imagem original
        linha = []    # Variável que vai guardar a linha que adionará na imagem com operação
        for j in range( len(imagem_original[0])-1, -1, -1 ):  # para toda coluna começando pelo final
            linha.append(imagem_original[i][j])  # adiciona o elemento na linha
        imagem.append(linha)   # adiciona a linha na imagem com a operação
    
    return imagem     # retorna a imagem com operação


def flip_vertical(imagem_original):
    imagem = []       # Variável que vai guardar a imagem com a operação
    for i in range( len(imagem_original)-1, -1, -1 ):  # para toda linha da imagem original começando pelo final
        linha = []    # Variável que vai guardar a linha que adionará na imagem com operação
        for j in range( len(imagem_original[0])):  # para toda coluna
            linha.append(imagem_original[i][j])  # adiciona o elemento na linha
        imagem.append(linha)   # adiciona a linha na imagem com a operação
    
    return imagem     # retorna a imagem com operação
    

def shift_vertical(imagem_original, x):
    imagem = []       # Variável que vai guardar a imagem com a operação
    for i in range( -x, len(imagem_original)-x, 1 ):  # para toda linha da imagem original começando pelo -x
        linha = []    # Variável que vai guardar a linha que adionará na imagem com operação
        for j in range( len(imagem_original[0])):  # para toda coluna
            linha.append(imagem_original[i][j])  # adiciona o elemento na linha
        imagem.append(linha)   # adiciona a linha na imagem com a operação
    
    return imagem     # retorna a imagem com operação
    

def shift_horizontal(imagem_original, x):
    imagem = []       # Variável que vai guardar a imagem com a operação
    for i in range(len(imagem_original)):  # para toda linha da imagem original
        linha = []    # Variável que vai guardar a linha que adionará na imagem com operação
        for j in range( -x, len(imagem_original[0])-x, 1):  # para toda coluna começando pelo -x
            linha.append(imagem_original[i][j])  # adiciona o elemento na linha
        imagem.append(linha)   # adiciona a linha na imagem com a operação
    
    return imagem     # retorna a imagem com operação
    

def crop(imagem_original, x1, y1, x2, y2):
    imagem = []       # Variável que vai guardar a imagem com a operação
    for i in range(x1-1, x2, 1):  # para toda linha da imagem original começando no x1 e terminando no x2
        linha = []    # Variável que vai guardar a linha que adionará na imagem com operação
        for j in range( y1-1, y2, 1):  # para toda coluna começando no y1 e terminando no y2
            linha.append(imagem_original[i][j])  # adiciona o elemento na linha
        imagem.append(linha)   # adiciona a linha na imagem com a operação
    
    return imagem     # retorna a imagem com operação
    

def shrink(imagem_original):
    imagem = []       # Variável que vai guardar a imagem com a operação
    for i in range(0, len(imagem_original), 2):  # para toda linha da imagem original pulando de 2 em 2
        linha = []    # Variável que vai guardar a linha que adionará na imagem com operação
        for j in range( 0, len(imagem_original[0]), 2 ):  # para toda coluna pulando de 2 em 2
            maximo = max(imagem_original[i][j], imagem_original[i][j+1], imagem_original[i+1][j], imagem_original[i+1][j+1])
            linha.append(maximo)  # adiciona o maior elemento entre os 4 ao redor na linha
        imagem.append(linha)   # adiciona a linha na imagem com a operação
    
    return imagem     # retorna a imagem com operação
    

# leitura da imagem
_ = input() #P2 - linha a ser ignorada

m, n = [int(x) for x in input().split()]

_ = input() #255 - linha a ser ignorada

imagem_original = []   # Variável que vai guardar a imagem original
for i in range(n):     # para toda linha da imagem
    linha = [int(x) for x in input().split()]  # Lê-se a linha
    imagem_original.append(linha)  # adiciona a linha na matriz


# leitura da operação e parâmetros

operacao = input()   # operação a aplicar nas imagens

if operacao == 'flip':  # se a operação for o flip
    operacao = input()  # pegamos se o flip é horizontal ou vertical
    if operacao == 'vertical':
        imagem = flip_vertical(imagem_original) 
    elif operacao == 'horizontal':
        imagem = flip_horizontal(imagem_original) 

elif operacao == 'shift':  # se a operação for o shift
    operacao = input()     # pegamos se o shift é horizontal ou vertical
    x = int(input())       # alem da quantidade de shift que vai ter
    if operacao == 'vertical':
        imagem = shift_vertical(imagem_original, x) 
    elif operacao == 'horizontal':
        imagem = shift_horizontal(imagem_original, x) 

elif operacao == 'crop':   # se a operação for o crop
    x1, y1 = [int(x) for x in input().split()]  # pegamos o ponto que terá o início do crop
    x2, y2 = [int(x) for x in input().split()]  # e o final do crop
    imagem = crop(imagem_original, x1, y1, x2, y2) 

elif operacao == 'shrink':   # se a operação for o shrink
    imagem = shrink(imagem_original)


# impressão da imagem final

imprimir_imagem(imagem)