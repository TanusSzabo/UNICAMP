###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 11 - Jogo da Similaridade Máxima
# Nome: 
# RA: 
###################################################

"""
Esta função recebe quatro parâmetros: 
 - linha: indíce de uma linha da matriz maior
 - coluna: indice de uma coluna da matriz maior
 - maior: matriz quandrada onde deve ser procurado um padrão 
 - menor: matriz quadrada com um padrão a ser encontrado

A função deve retornar o grau de similaridade entre a submatriz
da matriz maior que começa na posição definida pelos parâmetros 
linha e coluna e a matriz menor
"""
def calcula_similaridade(linha, coluna, maior, menor):
    n_menor = len(menor)   # Tamanho da matriz menor
    similaridade = 1.0     # similaridade começa no 100%, depois vamos diminuindo
    for i in range(n_menor):     # Para toda linha da matriz menor
        for j in range(n_menor): # e para toda coluna
            # Somamos os valores respectivos da matriz menor e maior naquela posição
            # se ambos forem iguais (0,0 ou 1,1) a soma vai dar um número par e, portanto
            # divisivel por 2 (soma%2 == 0)
            # Se ambos forem diferentes (0,1 ou 1,0) a soma vai dar impar (soma%2 == 1)
            # assim, conseguimos subtrair o peso de cada quadrado quando os casos são diferentes
            similaridade -= ( (menor[i][j]+maior[i+linha][j+coluna])%2 ) / (n_menor**2)
    
    return similaridade*100  # retorna a similaridade em porcentagem


# Leitura das matrizes

n_maior = int(input())   # tamanho da matriz maior
maior = []               # variável que irá guardar a matriz maior
for i in range(n_maior): # Para todos os valores de linha da matriz maior
    maior.append([int(x) for x in input().split()])  # le-se a linha separadinha bonitinho

n_menor = int(input())   # tamanho da matriz menor
menor = []               # variável que irá guardar a matriz menor
for i in range(n_menor): # Para todos os valores de linha da matriz menor
    menor.append([int(x) for x in input().split()])  # le-se a linha separadinha bonitinho


# Cálculo da submatriz de similaridade máxima
pos = [0,0]  # Variável que irá guardar a posição que ocorre a similaridade máxima
similaridade_maxima = 0  # variável que irá guardar a similaridade máxima

for i in range(n_maior):      # para toda linha i da matriz maior
    for j in range(n_maior):  # para toda coluna j da matriz maior
        if i + n_menor <= n_maior and j + n_menor <= n_maior:  # testa se a posição final da menor está dentro da maior
            similaridade = calcula_similaridade(i, j, maior, menor)  # se tiver, chama a função na posição i, j
            if similaridade > similaridade_maxima: # testa se a similaridade na posição é maior que a máxima antes guardada
                pos = [i, j]                       # se for, guarda a posição que ocorre esse novo máximo
                similaridade_maxima = similaridade # guarda o valor do novo máximo


# similaridade
print("Posição: ({0},{1})".format(pos[0], pos[1]))  # printa a posição que ocorre a similaridade máxima
print("Similaridade máxima: {:.2f}%".format(similaridade_maxima))  # printa a similaridade máxima