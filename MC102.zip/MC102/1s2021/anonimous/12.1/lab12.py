###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 12 - Processamento de Imagens
# Nome: 
# RA: 
###################################################
 
def imprimir_imagem(imagem):
    print("P2")
    print(len(imagem[0]), len(imagem))
    print("255")
    for i in range(len(imagem)):
        print(" ".join(str(x) for x in imagem[i]))


def flip(imagem_original):
    modo = input()    # modo horizontal ou vertical
    imagem = []       # Variável que vai guardar a imagem com a operação

    if modo == 'horizontal':
        for i in range(len(imagem_original)):        # para cada linha da imagem original
            imagem.append(imagem_original[i][::-1])  # adiciona a linha invertida na imagem
    
    elif modo == 'vertical':
        imagem = imagem_original[::-1]   # a imagem recebe a original com as linhas de maneira invertida
    
    return imagem     # retorna a imagem com operação


def shift(imagem_original):
    modo = input()    # modo horizontal ou vertical
    x = int(input())  # quantidade de pixels que irá shiftar
    imagem = []       # Variável que vai guardar a imagem com a operação

    if modo == 'horizontal':
        for i in range(len(imagem_original)):   # para cada linha da imagem original
            n = len(imagem_original[0]) - x     # pega a posição que irá ter o shift
            imagem.append(imagem_original[i][n:] + imagem_original[i][:n])  # adiciona a linha pela parte final e depois inicial
    
    elif modo == 'vertical':
        n = len(imagem_original) - x    # pega a posição que irá ter o shift
        imagem = imagem_original[n:] + imagem_original[:n]  # a imagem recebe as linhas finais e depois as iniciais
    
    return imagem     # retorna a imagem com operação


def crop(imagem_original):
    x1, y1 = [int(x) for x in input().split()]   # posição inicial do corte
    x2, y2 = [int(x) for x in input().split()]   # posição final do corte

    imagem = imagem_original[x1-1:x2]   # a imagem recebe as linhas da original dentro do corte vertical
    for i in range(len(imagem)):        # para cada linha da imagem com a operação
        imagem[i] = imagem[i][y1-1:y2]  # a linha é cortada na horizontal nos pontos
    
    return imagem     # retorna a imagem com operação

    
def shrink(imagem_original):
    imagem = []       # Variável que vai guardar a imagem com a operação

    for i in range(0, len(imagem_original), 2):  # para toda linha da imagem original pulando de 2 em 2
        linha = []    # Variável que vai guardar a linha que adionará na imagem com operação
        for j in range( 0, len(imagem_original[0]), 2 ):  # para toda coluna pulando de 2 em 2
            maximo = max(imagem_original[i][j], imagem_original[i][j+1], imagem_original[i+1][j], imagem_original[i+1][j+1])
            linha.append(maximo)  # adiciona o maior elemento entre os 4 ao redor daquela posição
        imagem.append(linha)   # adiciona a linha na imagem com a operação
    
    return imagem     # retorna a imagem com operação
    


# leitura da imagem
_ = input() #P2 - linha a ser ignorada

m, n = [int(x) for x in input().split()]  # tamanho da imagem em (coluna, linha)

_ = input() #255 - linha a ser ignorada

imagem_original = []  # Variável que vai guardar a imagem original
for i in range(n):    # para toda linha da imagem
    linha = [int(x) for x in input().split()]  # lese a linha
    imagem_original.append(linha)              # adiciona ela na imagem

operacao = input()   # operação que vamos aplicar
if operacao == 'flip':
    imagem = flip(imagem_original)
elif operacao == 'shift':
    imagem = shift(imagem_original)
elif operacao == 'crop':
    imagem = crop(imagem_original)
elif operacao == 'shrink':
    imagem = shrink(imagem_original)



# leitura da operação e parâmetros
imprimir_imagem(imagem)