###################################################
# MC102 - Algoritmos e Programação de Computadores
# Laboratório 14 - Caça-Números
# Nome: 
# RA: 
###################################################

"""
Essa função retorna verdadeiro se o número visto condiz com o padrão procurado, e false senão
"""
def eh_padrao(numero, padrao):
    if   numero == 1 and (padrao == 'A' or padrao == 'O' or padrao == 'S'):
        return True
    elif numero == 2 and (padrao == 'A' or padrao == 'E' or padrao == 'P'):
        return True
    elif numero == 3 and (padrao == 'A' or padrao == 'O' or padrao == 'P' or padrao == 'T'):
        return True
    elif numero == 4 and (padrao == 'A' or padrao == 'E' or padrao == 'C'):
        return True
    elif numero == 5 and (padrao == 'A' or padrao == 'O' or padrao == 'P'):
        return True
    elif numero == 6 and (padrao == 'A' or padrao == 'E' or padrao == 'C' or padrao == 'T'):
        return True
    elif numero == 7 and (padrao == 'A' or padrao == 'O' or padrao == 'P'):
        return True
    elif numero == 8 and (padrao == 'A' or padrao == 'E' or padrao == 'C'):
        return True
    elif numero == 9 and (padrao == 'A' or padrao == 'O' or padrao == 'C' or padrao == 'T'):
        return True
    else:
        return False
        

"""
Esta função recebe como parâmetro uma matriz, uma posição inicial na
matriz determinada pelos parâmetros linha e coluna e um padrão que
deve ser buscado em todas as direções (norte, sul, leste, oeste,
nordeste, sudeste, noroeste e sudoeste) a partir da posição inicial.
Caso o padrão seja encontrado a partir da posição inicial a função
deve retornar o valor True. Caso contrário, a função de retornar o
valor False.
"""
def busca_padrao(matriz, linha, coluna, padrao, x):
    if eh_padrao(matriz[linha][coluna], padrao[x]):  # se o número na posição tem o padrão procurado
        if x == len(padrao)-1:    # Se for a última letra procurada, significa que chegou no final da recurção
            return True           # e retorna verdadeiro

        else:                     # Se não, temos mais letras pra encontrar
            achou = False    # Variável que vai guardar se foi encontrado um caminho com números condizentes com os padroes
            """
            | (-1,-1)  (-1, 0)  (-1, +1) |
            | ( 0,-1)  ( 0, 0)  ( 0, +1) |
            | (+1,-1)  (+1, 0)  (+1, +1) |
            """
            for i in range(-1, 2, 1):     # Para as 3 linhas ao redor do item (-1, 0, 1)
                for j in range(-1, 2, 1): # Para as 3 colunas ao redor do item (-1, 0, 1)
                    # Se você não for a própria posição  E  a linha E a coluna estiverem dentro da matriz  E  ainda não ter encontrado um caminho
                    if (i!=0 or j!=0) and (0<=linha+i<len(matriz)) and (0<=coluna+j<len(matriz[0])) and (achou == False):
                        achou = busca_padrao(matriz, linha+i, coluna+j, padrao, x+1)  # Procura pra ver se aquela posição condiz com o proximo padrão
            
            return achou  # No final, retorna verdadeiro se encontrar um caminho e falso senão


    else:             # Se na posição não tiver um numero condizente com o padrão encontrado
        return False  # retorna falso


# Leitura da matriz

matriz = []  # Matriz de números
while True:
    entrada = input().split()  # Pega a linha de entrada splitada
    if entrada[0].isdigit():   # Se o primeiro valor for um digito, estamos lendo a matriz ainda
        matriz.append( [int(x) for x in entrada] )  # então adiciona os valores separadinhos bonitinho na matriz
    else:  # Senão, estamos lendo a linha com os padroes
        padrao = entrada[0]  # Salva os padroes e
        break                # sai do while

# Processamento da busca na matriz

posicoes = []  # Variável que vai guardar as posições que encontrou padrões
for i in range( len(matriz) ):         # Para toda linha da matriz
    for j in range( len(matriz[0]) ):  # Para toda coluna da matriz
        if busca_padrao(matriz, i, j, padrao, 0):  # Se naquela posiçao retornar um caminho favorável
            posicoes.append([i+1, j+1])            # adiciona a posição (começando do 1, e não do 0)


# Impressão das posições iniciais (linha e coluna)

# ...
if len(posicoes) == 0:   # se a lista de posições tiver tamanho 0, não encontrou nenhuma posição
    print("Nenhum padrao encontrado!")
else:                    # senão, alguma posição foi encontrada
    print(("Posicoes: " + " ".join([str((linha, coluna)) for linha, coluna in posicoes])).strip())
